# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 14:01:54 2017

@author: KarpikovIV
"""

def DepI(dic,*,cpn='CPN',par='PAR',rate='R',tim='TIME_ACC',lhs='LHS',sec='Security',pwa='P_wa'):
    def F(x):
        with localcontext() as ctx:
            ctx.prec = 1
            smm=0
            for j in range(len(dic[tim])):
                smm+=(dic[cpn][j]+dic[par][j])*np.exp(-(dic[rate][j]+x)*dic[tim][j])
            RES=float(Decimal(smm)-Decimal(dic[lhs]))
        return RES
    CALC=so.broyden1(F,0.05, f_tol=1)
    return CALC

def outer(CPN,cf,sec,dot,mat,G):
    def create_info(y):
        if y[1]!=y[1]: return np.nan
        date_today=y[2]
        b0=G.ix[date_today,'b0']
        b1=G.ix[date_today,'b1']
        b2=G.ix[date_today,'b2']
        tau=G.ix[date_today,'tau']
        ind=CPN[sec].index(y[0])
        COP={"Date":[] , "CPN":[], "PAR": [], "TIME_ACC":[], "R":[],'ISSUE_DT':np.nan,"MATURITY":np.nan,"PREV":np.nan,"PAR_RESID":np.nan,"DIF":[],"AC":np.nan,"LHS":np.nan} 
        n=len(CPN[cf][ind])
        k=int(n/3)
        COP['ISSUE_DT']=CPN[dot][ind]
        COP['MATURITY']=CPN[mat][ind]
        if date_today>COP['MATURITY'] or date_today<COP['ISSUE_DT']: return np.nan
        for j in range(k):
            COP["Date"].append(CPN[cf][ind][3*j])
            COP["DIF"].append((date_today-pd.Timestamp(CPN[cf][ind][3*j])).days)
            COP["CPN"].append(float(CPN[cf][ind][1+3*j]))
            COP["PAR"].append(float(CPN[cf][ind][2+3*j]))
        Tod_=[x for x in range(len(COP["DIF"])) if COP["DIF"][x]<0]
        if not Tod_: return np.nan
        try:
            COP['PREV']=min([COP['DIF'][x]/365 for x in range(len(COP['DIF'])) if COP['DIF'][x]>0 and COP['CPN'][x]!=0])
        except ValueError:
            COP['PREV']=(date_today-COP['ISSUE_DT']).days/365
        
        COP["Date"]=[COP["Date"][x] for x in Tod_]
        COP["CPN"]=[COP["CPN"][x] for x in Tod_]
        COP["PAR"]=[COP["PAR"][x] for x in Tod_]
        COP["DIF"]=[COP["DIF"][x] for x in Tod_]
        COP["PAR_RESID"]=sum(COP["PAR"])
        try:
            jk=min([x for x in range(len(COP["CPN"])) if COP["CPN"][x]!=0])
            COP["AC"]=COP["CPN"][jk]*COP["PREV"]
        except ValueError:
            COP["AC"]=0
        for j in range(len(COP["Date"])):
            x=-COP["DIF"][j]/365
            COP["TIME_ACC"].append(x)
            COP["R"].append((b0+(b1+b2)*tau/x*(1-np.exp(-x/tau))-b2*np.exp(-x/tau))/10000)
        COP["LHS"]=COP["AC"]+y[1]/100*COP["PAR_RESID"]
        try:
            FINRES=float(DepI(COP))
        except so.nonlin.NoConvergence:
            print('Did not converged: ',str(y[0])+', '+str(y[2]))
            return np.nan
        return FINRES
    return create_info
