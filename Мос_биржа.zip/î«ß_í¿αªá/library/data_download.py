# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 15:23:20 2017

@author: I
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 14:52:08 2017

@author: I
"""
import numpy as np
import pandas as pd 
import tkinter as tk
from tkinter import filedialog as fd
import datetime as dt
import time
import os
import itertools as it
import scipy.optimize as so
from scipy.optimize import curve_fit
import sys
from decimal import Decimal, localcontext

def winstring(text="Введите текст:", mes="Поле для ввода"):
    """ Редактор одной строки """
    root = tk.Tk()
    v = tk.StringVar()
    w = tk.Label(root, text=text)
    w.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    w.pack(side=tk.LEFT)
    v.set(mes)
    ent = tk.Entry(root, textvariable=v, bg="blue", fg="white")
    ent.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    ent.pack(side=tk.LEFT)
    but = tk.Button(root, text="OK", fg="green", command=root.destroy)
    but.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    but.pack(side=tk.BOTTOM)
    root.mainloop()
    txt = v.get()
    return txt

def str_to_ts(x):
    if type(x)==str:
        a=x[0:2]
        b=x[3:5]
        c=x[6:]
        y='.'.join([b,a,c])
        x=pd.Timestamp(y)
    return x

def givenm(excelnm,NAs):
    for name in excelnm.sheet_names:
        sys.modules['__main__'].__setattr__(name, excelnm.parse(sheetname=name,na_values=NAs))

def choose_excel_G():
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title="Выберите файл с параметрами G-кривой", defaultextension=".xlsx", 
                            filetypes=[("Таблицы Excel", ".xlsx")], initialdir=os.getcwd()) 
    root.destroy()
    xls_file = pd.ExcelFile(fph)
    return xls_file

def choose_excel_Z():
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title="Выберите файл с данными по корпоративным облигациям", defaultextension=".xlsx", 
                            filetypes=[("Таблицы Excel", ".xlsx")], initialdir=os.getcwd()) 
    root.destroy()
    xls_file = pd.ExcelFile(fph)
    return xls_file

def choose_excel():
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title="Выберите файл с данными", defaultextension=".xlsx", 
                            filetypes=[("Таблицы Excel", ".xlsx")], initialdir=os.getcwd()) 
    root.destroy()
    xls_file = pd.ExcelFile(fph)
    return xls_file



def compare(DF, names):
    res=DF
    if set(names) & set(DF.columns)!=set(names):
        comp=DF.apply(lambda x: set(names) & set(x)==set(names),axis=1)
        res=DF.ix[comp[comp].index[0]+1:,:]
        res.columns=DF.ix[comp[comp].index[0],:]
    return res

def drop_ind(D):
    for key in D.keys():
        D[key]=list(D[key].values())
    return D

def create_CF(General,*,cf,sec,dot,mat):
    CPN=pd.DataFrame(list(General[sec]),columns=['Security'],index=General.index)
    CPN['CF']=General[cf].apply(lambda x: x.split())
    CPN['ISSUE_DT']=General[dot].apply(str_to_ts)
    CPN['MATURITY']=General[mat].apply(str_to_ts)
    CPN=CPN.to_dict()
    return drop_ind(CPN)

def col(x):
    y=x.name
    res=[[y] +[k] for k in x]
    return res

def row(x):
    y=x.name
    res=[k+[y] for k in x]
    return res


def DepI(dic,*,cpn='CPN',par='PAR',rate='R',tim='TIME_ACC',lhs='LHS',sec='Security',pwa='P_wa'):
    def F(x):
        with localcontext() as ctx:
            ctx.prec = 100
            smm=0
            for j in range(len(dic[tim])):
                smm+=(dic[cpn][j]+dic[par][j])*np.exp(-(dic[rate][j]+x)*dic[tim][j])
            RES=float(Decimal(smm)-Decimal(dic[lhs]))
        return RES
    CALC=so.broyden1(F,0.05, f_tol=1)
    return CALC

def P_F(D,x):
    smm=0
    for j in range(len(D['TIME_ACC'])):
        smm+=(D['CPN'][j]+D['PAR'][j])*np.exp(-(D['R'][j]+x)*D['TIME_ACC'][j])
    RES=smm
    return RES

    

def outer(CPN,cf,sec,dot,mat,G):
    def create_info(y):
        if y[1]!=y[1]: return np.nan
        date_today=y[2]
        b0=G.ix[date_today,'b0']
        b1=G.ix[date_today,'b1']
        b2=G.ix[date_today,'b2']
        tau=G.ix[date_today,'tau']
        ind=CPN[sec].index(y[0])
        COP={"Date":[] , "CPN":[], "PAR": [], "TIME_ACC":[], "R":[],'ISSUE_DT':np.nan,"MATURITY":np.nan,"PREV":np.nan,"PAR_RESID":np.nan,"DIF":[],"AC":np.nan,"LHS":np.nan} 
        n=len(CPN[cf][ind])
        k=int(n/3)
        COP['ISSUE_DT']=CPN[dot][ind]
        COP['MATURITY']=CPN[mat][ind]
        if date_today>COP['MATURITY'] or date_today<COP['ISSUE_DT']: return np.nan
        for j in range(k):
            COP["Date"].append(CPN[cf][ind][3*j])
            COP["DIF"].append((date_today-str_to_ts(CPN[cf][ind][3*j])).days)
            COP["CPN"].append(float(CPN[cf][ind][1+3*j]))
            COP["PAR"].append(float(CPN[cf][ind][2+3*j]))
        Tod_=[x for x in range(len(COP["DIF"])) if COP["DIF"][x]<0]
        if not Tod_: return np.nan
        try:
            COP['PREV']=min([COP['DIF'][x]/365 for x in range(len(COP['DIF'])) if COP['DIF'][x]>0 and COP['CPN'][x]!=0])
        except ValueError:
            COP['PREV']=(date_today-COP['ISSUE_DT']).days/365
        
        COP["Date"]=[COP["Date"][x] for x in Tod_]
        COP["CPN"]=[COP["CPN"][x] for x in Tod_]
        COP["PAR"]=[COP["PAR"][x] for x in Tod_]
        COP["DIF"]=[COP["DIF"][x] for x in Tod_]
        COP["PAR_RESID"]=sum(COP["PAR"])
        try:
            jk=min([x for x in range(len(COP["CPN"])) if COP["CPN"][x]!=0])
            COP["AC"]=COP["CPN"][jk]*COP["PREV"]
        except ValueError:
            COP["AC"]=0
        for j in range(len(COP["Date"])):
            x=-COP["DIF"][j]/365
            COP["TIME_ACC"].append(x)
            COP["R"].append((b0+(b1+b2)*tau/x*(1-np.exp(-x/tau))-b2*np.exp(-x/tau))/10000)
        COP["LHS"]=COP["AC"]+y[1]/100*COP["PAR_RESID"]
        if len(COP["Date"])==1:
            return (np.log(sum(COP["CPN"]+COP["PAR"])/COP["LHS"])-COP["TIME_ACC"][0]*COP["R"][0])/COP["TIME_ACC"][0]
        else:
            fit,cov=curve_fit(P_F, COP, COP["LHS"],bounds=(-0.1, 1))          
            return fit[0]
    return create_info

def weeked(x):
    Y=str(x)[0:4]
    M=str(x)[5:7]
    D=str(x)[8:10]
    res=dt.date(int(Y),int(M),int(D)).weekday()
    return True if res<5 else False

def outr(a):
    def recur(x):
        L=[]
        ind=np.nan
        for i in range(len(x)): 
            if x[i]==x[i]: 
                ind=i
                break
            else: L.append(0)
        if ind!=ind: pass
        else:
            tr=True
            for i in range(ind,len(x)):
                if tr:
                     L.append(x[i])
                     tr=False
                else:
                    if x[i]==x[i]:
                        if L[i-1]!=0:
                            L.append((1-a)*L[i-1]+a*x[i])
                        else: L.append(x[i])
                    else: L.append(0)
        return L
    return recur

def ziss(x):
    L=[]
    tr=True
    for i in range(len(x)):
        if tr:
            L.append((x[i][0]+x[i][2]*x[i][3])/(x[i][1]+x[i][3]))
            tr=False
        else:
            L.append((x[i][0]+L[i-1]*x[i][3])/(x[i][1]+x[i][3]))
    return L


def Settle(x):
    P_theor=[]
    P_sttlmnt=[]
    if x[0][1]==x[0][1]:
        for i in range(len(x)):
            if x[i][1]==x[i][1]: P_theor.append(x[i][1])
            else: P_theor.append(P_sttlmnt[i-1])
            if x[i][0]==x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(np.median([x[i][0],P_theor[i],x[i][2]]))
            if x[i][0]!=x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(min([P_theor[i],x[i][2]]))
            if x[i][0]==x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(max([P_theor[i],x[i][0]]))
            if x[i][0]!=x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(P_theor[i])
    
    else:
        for i in range(len(x)):
            P_theor.append(np.nan);P_sttlmnt.append(np.nan)
            if x[i][1]: 
                indstart=i
                break
        for i in range(indstart,len(x)):
            if x[i][1]==x[i][1]: P_theor.append(x[i][1])
            else: P_theor.append(P_sttlmnt[i-1])
            if x[i][0]==x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(np.median([x[i][0],P_theor[i],x[i][2]]))
            if x[i][0]!=x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(min([P_theor[i],x[i][2]]))
            if x[i][0]==x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(max([P_theor[i],x[i][0]]))
            if x[i][0]!=x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(P_theor[i])
    return P_sttlmnt

