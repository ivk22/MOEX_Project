# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 20:35:58 2017

@author: I
"""

import os

directory=input('Введите путь к данному файлу: ')
os.chdir(directory)

import numpy as np
import pandas as pd 
from library import *
from library import sobol_seq
from library import data_download as dd
import datetime as dt
from os import listdir
import sys
import math
import re
from functools import partial
from scipy.optimize import curve_fit
from scipy.optimize import fsolve
from library import sobol_seq

# Загрузка данных по корпоративным облигациям

xls_file=dd.choose_excel_Z()

# Объявления некоторых функций общего назначения

def toCF(x):
    """
    Функция преобразования данных о денежных потоках первого типа
    """
    x=x.split()
    y=np.array(x)
    y=y.reshape(int(len(x)/3),3)
    y=pd.DataFrame(y,columns=['Date','CPN','PAR'])
    z=y[['CPN','PAR']]
    z.index=y.Date.apply(str_to_ts)
    z.CPN=z.CPN.apply(lambda x:float(x))
    z.PAR=z.PAR.apply(lambda x:float(x))
    return z

def toCF2(x):
    """
    Функция преобразования данных о денежных потоках второго типа
    """
    y=np.array(x)
    y=y.reshape(int(len(x)/3),3)
    y=pd.DataFrame(y,columns=['Date','CPN','PAR'])
    z=y[['CPN','PAR']]
    z.index=y.Date.apply(str_to_ts)
    z.CPN=z.CPN.apply(lambda x:float(x))
    z.PAR=z.PAR.apply(lambda x:float(x))
    return z



def tofact(x):
    """
    Функция преобразования данных об амортизации номинала
    """
    if x==x:
        x=x.split()
        y=np.array(x)
        y=y.reshape(int(len(x)/2),2)
        y=pd.DataFrame(y,columns=['Date','Factor'])
        z=y['Factor']
        z.index=y.Date.apply(str_to_ts)
        z=z.apply(lambda x:float(x))
        return z
    else: return np.nan

def str_to_ts(x):
    """
    Функция обращения строчного формата в формат даты
    """
    if type(x)==str:
        a=x[0:2]
        b=x[3:5]
        c=x[6:]
        y='.'.join([b,a,c])
        x=pd.Timestamp(y)
    return x


# Загрущзка данных с параметрами G-кривой

G=dd.choose_excel_G()

na_v=['#N/A Field Not Applicable', '#N/A N/A', '#N/A','NA','#NA','N/A', 'Na','na','#N/A Invalid Field', '#N/A Invalid Security', '#N/A Invalid Parameter']

dd.givenm(xls_file,na_v)
dd.givenm(G,na_v)
# Обработка и преобразование данных
var=['Краткое название эмитента','ISIN','DES_CASH_FLOW','MATURITY','ISSUE_DT']
# Выкидываем облигации, по которым отсутствуют ключевые данные
General=dd.compare(GENERAL, var)
General2=General.loc[General[var].dropna().index,:]

# преобразуем строки в даты в массиве с общии данными

General2['Дата ближайшей оферты put']=General2['Дата ближайшей оферты put'].apply(str_to_ts)
General2['Дата ближайшей оферты call']=General2['Дата ближайшей оферты call'].apply(str_to_ts)
General2['MATURITY']=General2['MATURITY'].apply(str_to_ts)

General2['MATURITY']=(General2['Дата ближайшей оферты call'].apply(lambda x: [x])+General2['Дата ближайшей оферты put'].apply(lambda x: [x])+General2['MATURITY'].apply(lambda x: [x]))

def tomat(x):
    """
    Функция - заглушка для отсутствующих дат погашения
    """
    if x[0]==x[0] or x[1]==x[1]:
        return np.min(pd.Series([x[0],x[1]]))
    else: return x[2]
    
General2['MATURITY']=General2['MATURITY'].apply(lambda x: np.min(pd.Series(x)))
General2[['Дата ближайшей оферты call','Дата ближайшей оферты put','MATURITY']]
General2=General2[General2['MATURITY']==General2['MATURITY']]

General2=General2.iloc[:,:-2]


def emitdr(x):
    """
    Проверка наличия ключевых слов в описании конвенции
    """
    if 'эми' in x: return False
    elif 'Эми' in x: return False
    else: return True

# Выкидываем флоатеры, у которых отсутствуют ключевые данных
General2=General2.loc[General2['Ставка купона'].apply(lambda x: x==x),:]
General2=General2.loc[General2['Периодичность выплаты купонов'].apply(lambda x: x==x),:]
General2=General2.loc[General2['Конвертируемость'].apply(lambda x: x=='Нет'),:]
General2=General2.loc[General2['Периодичность выплаты купонов'].apply(lambda x: x==x),:]


# Вы деляем ключевые столбцы для флоатеров в массив Emitnm2
Emitnm=General2[General2['Плавающая ставка']=='Да'][['Краткое название эмитента','Базовая ставка','Ставка купона','SIGMA','ALPHA','GAMMA','PREM','NFIXED','FIXED','INTER']]
Emitnm2=Emitnm.loc[Emitnm.loc[:,'SIGMA':'PREM'].dropna(how='any').index,:]


General2['Базовая ставка'].fillna('Fixed',inplace=True)
arrays=[np.array(General2['Базовая ставка']),np.array(General2['Краткое название эмитента'])]

Generalx=General2.T
Generalx.columns=arrays

# Группировка данных по эмитентам
Groups=General2.groupby('Краткое название эмитента')


# Разбиваем эмитентов на эмитентов с фиксированным и плавющим долгом и эмитентов только с плавающим долгом
smg=pd.Series([sum(Groups.get_group(name)['Плавающая ставка'].apply(lambda x: x=='Нет')) for name in Groups.groups],index=Groups.groups.keys())

Fgr=smg[smg==0].index
Sgr=smg[smg!=0].index

F_G=pd.concat([Groups.get_group(name) for name in Fgr])
S_G=pd.concat([Groups.get_group(name) for name in Sgr])


Groups_by_F=S_G.groupby('Плавающая ставка')

# Выделение облигаций с фиксированной ставкой в массив S_G_F. Сейчас мы работаем только с такими облигациями. Обозначим этот момент, как *.

S_G_F=Groups_by_F.get_group('Нет').dropna(axis=1,how='all')


def dropfx2(x):
    """Удаление облигаций с плавающей ставкой, ошибочно отмеченных как облигации с фиксированной ставкой
    """
    if 'дополнительный' in x: return False
    elif 'переменный' in x: return False
    elif 'коэффициент' in x: return False
    elif 'Дополнительный' in x: return False
    elif 'Переменный' in x: return False
    elif 'Коэффициент' in x: return False
    elif 'удержание' in x: return False
    elif 'Удержание' in x: return False
    elif 'дополнительная' in x: return False
    elif 'Дополнительная' in x: return False
    elif 'вычитание' in x: return False
    elif 'Вычитание' in x: return False
    elif 'Формул' in x: return False
    elif 'формул' in x: return False
    elif 'Плав' in x: return False
    elif 'Ключ' in x: return False
    elif 'ИПЦ' in x: return False
    elif 'max' in x: return False
    elif 'Max' in x: return False
    elif 'Min' in x: return False
    elif 'min' in x: return False
    elif 'ЦБ' in x: return False
    elif 'РФ' in x: return False
    elif 'RU' in x: return False
    elif 'Ru' in x: return False
    elif 'MO' in x: return False
    elif 'Mo' in x: return False
    elif 'ru' in x: return False
    elif 'mo' in x: return False
    elif 'RO' in x: return False
    elif 'Ro' in x: return False
    elif 'ro' in x: return False
    else: return True



def getdates(dat,x):
    """
    Использование информации с поля FACTOR_SCHEDULE для снижения вероятности использовать неправильные данных (функция не является значимой)
    """
    if not x[0]:
        cf=dat.loc[x[1],x[2]]['DES_CASH_FLOW']
        mat=dat.loc[x[1],x[2]]['MATURITY']
        iss=dat.loc[x[1],x[2]]['ISSUE_DT']
        ilast=list(cf.index)[-1]
        if abs(ilast-mat).days<=15: 
            cf.iloc[-1,1]=1000000.-sum(cf.iloc[:-1,1])
            return cf
        freq=365//dat.loc[x[1],x[2]]['Freq']
        nper=(mat-ilast).days//freq-1
        X=[]
        for i in range(nper):
            ilast+=pd.Timedelta(days=freq)
            X.append(ilast)
        X.append(mat)
        ser=pd.DataFrame(0,index=X,columns=['CPN','PAR'])
        datf=cf.append(ser)
        comp=datf.PAR[datf.PAR==1000000.].index
        if comp!=list(datf.index)[-1]:
            datf.loc[comp,'PAR']=0
            datf.loc[list(datf.index)[-1],'PAR']=1000000.-sum(datf.loc[list(datf.index)[:-1],'PAR'])
            
        else: datf.loc[list(datf.index)[-1],'PAR']=1000000.-sum(datf.loc[list(datf.index)[:-1],'PAR'])
        if list(datf.index)[-1]<list(datf.index)[-2]:
            serd=pd.Series(list(datf.index)[:-1])
            bol=(serd-list(datf.index)[-1]).apply(lambda x: abs(x))
            bol2=bol[bol==np.min(bol)].index
            dat=serd[bol2[0]]
            datf=datf.loc[:dat,:]
            datf.iloc[-1,1]=1000000.-np.sum(datf.iloc[:-1,1])
        return datf
    else:
        cf=dat.loc[x[1],x[2]]['DES_CASH_FLOW']
        mat=dat.loc[x[1],x[2]]['MATURITY']
        iss=dat.loc[x[1],x[2]]['ISSUE_DT']
        cf=cf.loc[:mat,:]
        cf.iloc[-1,1]=1000000.-np.sum(cf.iloc[:-1,1])
        return cf


# удаляем флоатеры, которые ошибочно были отмечены как облигации с фиксированной ставко
S_G_F2=S_G_F.loc[S_G_F['Ставка купона'].apply(dropfx2),:]

laternams=S_G_F2.ISIN
# Из информации о CF вытаскиваем дату последнего платежа
S_G_F2['Newmat']=S_G_F2['DES_CASH_FLOW'].apply(lambda x: x.split())

S_G_F2['Newmat']=S_G_F2['Newmat'].apply(lambda x: str_to_ts(x[-3]))


S_G_F2['Newmat']=(S_G_F2['Newmat']-S_G_F2['MATURITY'])
S_G_F2['Newmat']=S_G_F2['Newmat'].apply(lambda x: x.days)

# Приверяем расхождение даты погашения с датой последнего платежа. Если расхождение > 15 дней - выкидываем облигацию

S_G_F2['Newmat']=S_G_F2['Newmat'].apply(lambda x: abs(x))

kp=S_G_F2['Newmat'].apply(lambda x : x<15)


S_G_F2=S_G_F2[kp]
S_G_F2['Dates']=S_G_F2['DES_CASH_FLOW']


def cout(y):
    """
    Функция, высчитывающая остаточный номинал
    """
    x=y.split()
    k=len(x)//3
    sm=0
    for i in range(k-1):
        sm+=float(x[3*i+2])
    y=' '.join(x[:-1])
    y+=" "+str(1000000-sm)
    return y

def ssm(y):
    x=y.split()
    k=len(x)//3
    sm=0
    for i in range(k):
        sm+=float(x[3*i+2])
    return sm==1000000

S_G_F2['DES_CASH_FLOW']=S_G_F2['Dates'].apply(cout)

Emit_F=S_G_F2.groupby('Краткое название эмитента')
def notNan(x):
    return 0 if x!=x else x



# Выделяем массив с оцененными параметрами G-кривой
Sheet1=dd.compare(Sheet1, ['Date','b0','b1','b2','tau'])
Sheet1.index=Sheet1['Date']

Sheet1=Sheet1.loc[:,['b0','b1','b2','tau']]

nam_f=S_G_F2['FULL']

# Выделение цен бидов, асков и объемов торгов по облигациям, попавшим на этап расчета первичного Z-спреда

stnam_f=['Date']+list(nam_f)
PX_ASK_F=dd.compare(PX_ASK, stnam_f);PX_ASK2_F=PX_ASK_F[nam_f];PX_ASK2_F.index=PX_ASK_F['Date'].apply(dd.str_to_ts)
PX_VOLUME_F=dd.compare(PX_VOLUME, stnam_f);PX_VOLUME2_F=PX_VOLUME_F[nam_f];PX_VOLUME2_F.index=PX_VOLUME_F['Date'].apply(dd.str_to_ts)
AVG_PX_F=dd.compare(AVG_PX, stnam_f);AVG_PX2_F=AVG_PX_F[nam_f];AVG_PX2_F.index=AVG_PX_F['Date'].apply(dd.str_to_ts)
PX_BID_F=dd.compare(PX_BID, stnam_f);PX_BID2_F=PX_BID_F[nam_f];PX_BID2_F.index=PX_BID_F['Date'].apply(dd.str_to_ts)

inddat=pd.Series(AVG_PX2_F.index)[pd.Series(AVG_PX2_F.index).apply(dd.weeked)]
# Убираем выходные дни из массивов
PX_ASK2_F=PX_ASK2_F.ix[inddat,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[inddat,:]
AVG_PX2_F=AVG_PX2_F.ix[inddat,:]
PX_BID2_F=PX_BID2_F.ix[inddat,:]

indeq=pd.Index(sorted(set(Sheet1.index) & set(PX_ASK2_F.index)))
# Проверяем, выкидываем все даты, на которые параметров G-кривой не существует
PX_ASK2_F=PX_ASK2_F.ix[indeq,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[indeq,:]
AVG_PX2_F=AVG_PX2_F.ix[indeq,:]
PX_BID2_F=PX_BID2_F.ix[indeq,:]
Sheet1=Sheet1.ix[indeq,:]

# Формируем массив данных для расчета первичного Z-спреда облигаций
CPN=dd.create_CF(S_G_F2,cf='DES_CASH_FLOW',sec='FULL',dot='ISSUE_DT',mat='MATURITY')

gf=AVG_PX2_F.apply(dd.col).apply(dd.row, axis=1)
fin=dd.outer(CPN,cf='CF',sec='Security', dot='ISSUE_DT',mat='MATURITY',G=Sheet1)



Z_WA=gf.applymap(fin)

def less(x):
    """
    Функция, проверяющая полученные результаты по Z-спредам на адекватность: выкидываются все облигации по которым отмечены устойчиво отрицательные значения Z-спредов; облигации, по которым имеется слишком большие значение (>10%) значения или слишком маленькие (<-2%) значения 
    """
    if sum(x.apply(lambda y: y<=-0.02))>0 or sum(x.apply(lambda y: y<-0))>len(x)//2 or sum(x.apply(lambda y: y>0.1))>0: return True
    else: return False

k=Z_WA.apply(less,axis=0)
# Расчет первичного Z-спреда облигаций
p=pd.Series(k[k==True].index)
p=p.apply(lambda x: x[:-5])
p=p.apply(lambda x: x+" Corp")
Z_WA=Z_WA.drop(p,axis=1)

Z_WA=Z_WA.dropna(how='all',axis=1)

Z_WA=Z_WA.fillna(method='ffill').fillna(method='bfill')
# Запись результатов в файл
writer = pd.ExcelWriter('Z_WA1.xlsx')
Z_WA.to_excel(writer,'Z_WA1')
writer.save()
# Выбрасываем все облигации, которые отсеялись на этапе расчета первичного Z-спреда из массивов
PX_ASK2_F=PX_ASK2_F[Z_WA.columns]
AVG_PX2_F=AVG_PX2_F[Z_WA.columns]
PX_BID2_F=PX_BID2_F[Z_WA.columns]
PX_VOLUME2_F=PX_VOLUME2_F[Z_WA.columns]
P_sttm1_F=PX_ASK2_F.applymap(lambda x: [x])+AVG_PX2_F.applymap(lambda x: [x])+PX_BID2_F.applymap(lambda x: [x])

def pst(x):
    """
    Функция возращает значения P_sttm, по алгоритму, определенному в методологии
    """
    
    if x[1]!=x[1]: return np.nan
    if x[0]==x[0] and x[2]==x[2]:
        return np.median(x)
    if x[0]==x[0]: return min(x[0],x[1])
    if x[2]==x[2]: return max(x[1],x[2])
    else: return x[1]


P_int=P_sttm1_F.applymap(pst)

P_sttm2_F=PX_ASK2_F.applymap(lambda x: [x])+P_int.applymap(lambda x: [x])+PX_BID2_F.applymap(lambda x: [x])

P_stm=P_sttm2_F.applymap(pst)

gf2=P_stm.apply(dd.col).apply(dd.row, axis=1)

# Расчет Z_sttm, по алгоритму, определенному в методологии

Z_ST=gf2.applymap(fin)

Z_ST=Z_ST.fillna(method='ffill').fillna(method='bfill')

S_G_F2.index=S_G_F2['FULL']

S_G_F2=S_G_F2.loc[Z_ST.columns,:]

Emit_F=S_G_F2.groupby('Краткое название эмитента')

# Расчет первичного Z-спреда эмитентов
# Ввод коэф-та масштабирования и коэф-та рекурсии
scale=float(gui.winfor(text='Введите коэффициент масштаба (scale): ', mes=''))
alpha=float(gui.winfor(text='Введите коэффициент сглаживвние ликвидности (alpha): ', mes=''))

Z_WA=Z_WA.iloc[1:,:]
Z_ST=Z_ST.iloc[:-1,:]
Z_ST.index=Z_WA.index

# Расчет ликвидности облигации
l=PX_VOLUME2_F.iloc[1:,:]/np.exp(scale*abs(Z_WA-Z_ST))

def getdat(dat,x):
    """
    Функция - заглушка для определения нулевого элемента рекурсии
    """
    nm=list(dat.index)
    if nm.index(x.name)>0: ind=nm[nm.index(x.name)-1]
    else: ind=nm[nm.index(x.name)] 
    return dat.loc[ind,:]

gd=partial(getdat,l)

def liq(x):
    """
    Функция, рекурсивно переоценивающая ликвидность облигации
    """
    if x[1]==x[1]:return alpha*x[0]+(1-alpha)*x[1]
    else: return x[0]
    
# Расчет ликвидности эмитента

L=pd.DataFrame(0,index=l.index,columns=l.columns)

for index in L.index:
   dt=l.loc[index,:].apply(lambda x: [x])+gd(l.loc[index,:]).apply(lambda x: [x])
   L.loc[index,:]=dt.apply(liq)

Ser_F=[pd.Series(Emit_F.get_group(name)['FULL'],name=name) for name in Emit_F.groups]

# Расчет параметров, необходимых для определения ликвидности эмитента

L_iss=[pd.Series(L[ser].apply(np.mean,axis=1),name=ser.name) for ser in Ser_F]

L_ISS=pd.DataFrame({b.name:b for b in L_iss})

l_Z=[pd.Series((Z_WA[ser]*l[ser]).apply(np.sum,axis=1),name=ser.name) for ser in Ser_F]
l_ZISS=pd.DataFrame({b.name:b for b in l_Z})

l_l=[pd.Series(l[ser].apply(np.sum,axis=1),name=ser.name) for ser in Ser_F]
l_lISS=pd.DataFrame({b.name:b for b in l_l})

gdl=partial(getdat,L_ISS)
L_ISS2=L_ISS.apply(gdl,axis=1)
L_ISS2.index=L_ISS.index

# Собираем все показатели в один массив ISS

ISS=l_ZISS.applymap(lambda x:[x])+L_ISS2.applymap(lambda x:[x])+l_lISS.applymap(lambda x:[x])

def liqs(x):
    return x[0]/x[2]

def liq2(x):
    if x[3]==x[3] and x[1]==x[1]:
        return (x[0]+x[3]*x[1])/(x[2]+x[1])
    else:
        return liqs(x)
# Рекурсивно оцениваем Z-спреад эмитента
tr=False
for i in range(len(ISS)):
    if not tr:
        ISS.iloc[i,:]=ISS.iloc[i,:].apply(liqs)
        tr=True
    else:
        dt=ISS.iloc[i,:]+ISS.iloc[i-1,:].apply(lambda x: [x])
        ISS.iloc[i,:]=dt.apply(liq2)
ISS=ISS.fillna(method='ffill').fillna(method='bfill')
ISS=ISS.dropna(axis=1)

# Запись Excel-файла с расчетами первичного Z-спреда эмитентов

ISS=ISS.dropna(axis=1)
writer = pd.ExcelWriter('ISS1.xlsx')
ISS.to_excel(writer,'ISS1')
writer.save()

# Тут мы заканчиваем работу с облигациями с фиксированной доходностью. Обозначем этот момент, как **

# Выделение и обработка данных по облигациям с плавающей ставкой

F_G_F=Groups_by_F.get_group('Да')

nmex=list(set(F_G_F['Краткое название эмитента'])-(set(F_G_F['Краткое название эмитента'])&set(ISS.columns)))
def nres(nm,x):
    if x in nm:return True
    else: return False
nnam=partial(nres,nmex)

# Первичная обработка данных. Удаляем облигации, по которым отсутствует критическая информация.

F_G=F_G.append(F_G_F[F_G_F['Краткое название эмитента'].apply(nnam)])

F_G_F=F_G_F.drop(F_G_F[F_G_F['Краткое название эмитента'].apply(nnam)].index)

F_G=F_G.loc[sorted(F_G.index),:]
F_G=F_G[F_G['SIGMA']==F_G['SIGMA']]
F_G[['NFIXED','FIXED']]=F_G[['NFIXED','FIXED']].applymap(notNan)


F_G=F_G[F_G['Периодичность выплаты купонов']==F_G['Периодичность выплаты купонов']]
F_G_F=F_G_F[F_G_F['SIGMA']==F_G_F['SIGMA']]
F_G_F[['NFIXED','FIXED']]=F_G_F[['NFIXED','FIXED']].applymap(notNan)
F_G_F=F_G_F[F_G_F['Периодичность выплаты купонов']==F_G_F['Периодичность выплаты купонов']]

F_G_F['ISS']=F_G_F['Краткое название эмитента']
F_G_F['ISS']=F_G_F['ISS'].apply(lambda x: ISS[x][-1])

Fdat=F_G_F[['Краткое название эмитента','SIGMA','ALPHA','GAMMA','PREM','NFIXED','FIXED','INTER','Ставка купона','Периодичность выплаты купонов','Базовая ставка','MATURITY','ISSUE_DT','DES_CASH_FLOW','FACTOR_SCHEDULE','ISIN','ISS']]

Fdat.columns=['Emit','SIGMA','ALPHA','GAMMA','PREM','NFIXED','FIXED','INTER','Conv','Freq','Base','MATURITY','ISSUE_DT','DES_CASH_FLOW','FACTOR_SCHEDULE','ISIN','ISS']
Fdat.index=F_G_F['ISIN']

def todate(dat,x):
    """
    Функция, рассчитывающая дату погашения облигаций с плавающей ставкой, если найдено не соответствие с информацией по CF
    """
    if dat.loc[x,'MATURITY'] in dat.loc[x,'DES_CASH_FLOW'].index:
        return list(dat.loc[x,'DES_CASH_FLOW'].index)[-2]
    else:
        return dat.loc[x,'MATURITY']-pd.Timedelta(days=365//dat.loc[x,'Freq'])


# Применение ранее объявленных функций для коррекции данных
Fdat.DES_CASH_FLOW=Fdat.DES_CASH_FLOW.apply(toCF)
FULLCF=Fdat.DES_CASH_FLOW
Fdat.FACTOR_SCHEDULE=Fdat.FACTOR_SCHEDULE.apply(tofact)
Fdat.MATURITY=Fdat.MATURITY.apply(str_to_ts)
Fdat.ISSUE_DT=Fdat.ISSUE_DT.apply(str_to_ts)

nam_f=pd.Series(Fdat.index).apply(lambda x: x+' Corp')
stnam_f=['Date']+list(nam_f)
PX_ASK_F=dd.compare(PX_ASK, stnam_f);PX_ASK2_F=PX_ASK_F[nam_f];PX_ASK2_F.index=PX_ASK_F['Date'].apply(dd.str_to_ts)
PX_VOLUME_F=dd.compare(PX_VOLUME, stnam_f);PX_VOLUME2_F=PX_VOLUME_F[nam_f];PX_VOLUME2_F.index=PX_VOLUME_F['Date'].apply(dd.str_to_ts)
AVG_PX_F=dd.compare(AVG_PX, stnam_f);AVG_PX2_F=AVG_PX_F[nam_f];AVG_PX2_F.index=AVG_PX_F['Date'].apply(dd.str_to_ts)
PX_BID_F=dd.compare(PX_BID, stnam_f);PX_BID2_F=PX_BID_F[nam_f];PX_BID2_F.index=PX_BID_F['Date'].apply(dd.str_to_ts)

inddat=pd.Series(AVG_PX2_F.index)[pd.Series(AVG_PX2_F.index).apply(dd.weeked)]

PX_ASK2_F=PX_ASK2_F.ix[inddat,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[inddat,:]
AVG_PX2_F=AVG_PX2_F.ix[inddat,:]
PX_BID2_F=PX_BID2_F.ix[inddat,:]

indeq=pd.Index(sorted(set(Sheet1.index) & set(PX_ASK2_F.index)))

PX_ASK2_F=PX_ASK2_F.ix[indeq,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[indeq,:]
AVG_PX2_F=AVG_PX2_F.ix[indeq,:]
PX_BID2_F=PX_BID2_F.ix[indeq,:]
Sheet1=Sheet1.ix[indeq,:]


AVG_PX2_F=AVG_PX2_F.dropna(how='all',axis=1)

tod=list(AVG_PX2_F.index)[-1]

Fdat=Fdat.loc[pd.Series(AVG_PX2_F.columns).apply(lambda x: x[:-5]),:]



def plast(dat,x):
    """
    Функция, отыскивающая ближайшие цены к дате расчетов (дата расчета - последняя дата в массиве данных)
    """
    y=x.notnull()
    res=[x[max(y[y==True].index)]]+[max(y[y==True].index)]
    nm=x.name[:-5]
    cf=dat.loc[nm,'DES_CASH_FLOW']
    try:
        if bool(list(cf.loc[res[1]+pd.Timedelta(days=1):tod,:].index)): return np.nan
    except ValueError: pass
    dates=pd.Series(cf.index)
    dates.index=cf.index
    dates=dates.apply(lambda x: (x-res[1]).days)
    dates1=dates[dates>0]
    if not bool(list(dates1)): return np.nan
    date1=dates1[dates1==np.min(dates1)]
    dates2=dates[dates<=0]
    date2=dates2[dates2==np.max(dates2)]
    if not list(date2): date2=[(tod-dat.loc[nm,'ISSUE_DT']).days]
    nkd=(cf.loc[date1.index[0],'CPN']*abs(date2[0])/(abs(date2[0])+date1[0])/np.sum(cf.loc[date1.index[0]:,'PAR']))*100
    res[0]+=nkd
    return res
# Использование функции plast, определение крайних цен и дат торгов
topl=partial(plast,Fdat)
PLAST=AVG_PX2_F.apply(topl)
PLAST=PLAST[PLAST==PLAST]
AVG_PX2_F=AVG_PX2_F[PLAST.index]

PLAST.index=pd.Series(PLAST.index).apply(lambda x: x[:-5])

Fdat2=Fdat
Fdat2=Fdat2.loc[PLAST.index,:]

Fdat2['P']=PLAST

# Реализуем алгорит бутстрэппинга

def fdrug(dat,x):
    return dat.loc[x[1],x[0]]
Fdat2['TD']=Fdat2['Emit'].apply(lambda x: [x])+Fdat2['P'].apply(lambda x: [x[1]])
Fdat2['ISS']=Fdat2['TD'].apply(partial(fdrug,ISS))

def dropsim(p):
    """
    Функция, удаляющая n-1 облигацию, если у n облигаций совпадают временные интервалы
    """
    p1=p[:-1]
    p2=p[1:]
    p1.index=p2.index
    bol=(p2!=p1)
    bol1=bol[bol==False].index
    return p[p.index.difference(bol1)].sort_values()
    
def recur(s,x):
    h=s[s==x].index
    pos=s.index.get_loc(h[0])
    if pos!=0: return [s[pos-1],x]
    else: return [tod,x]
BGs=Fdat2.groupby('Base')


# Разбиваем в цикле весь массив по базовым ставкам и формируем упорядочение по временным интервалам для всех облигаций, привязанных к базовой ставке
Lambda={}
for gr in BGs.groups:
    dat=BGs.get_group(gr)
    dt=partial(todate,dat)
    dt2=pd.Series(dat.index).apply(dt)
    dt2.index=dat.index
    
    dates=dt2[dt2>tod]
    dates=dropsim(dates)
    
    f1=partial(recur,dates)
    dates2=dates.apply(f1)
    
    dat2=dat.loc[dates2.index,:]
    dat2['INTS']=dates2
    Lambda.update({gr:dat2})
    


SerL=pd.Series(Lambda)


def ismat(dat,x):
    """
    Промежуточная для to_df функция
    """
    
    if dat.loc[x,'MATURITY'] in list(dat.loc[x,'DES_CASH_FLOW'].index):
        return True
    else:
        return False


def to_df(x):
    """
    Функция, проверяющая наличие даты погашения из вкладки General в информации о CF
    """
    f1=partial(ismat,x)
    x['TRUE_CF']=list(pd.Series(x.index).apply(f1))
    return x
       

SerL2=SerL.apply(to_df)

def iffact(x):
    
    if isinstance(x[0],float): return np.nan
    else:
        l=pd.Series(x[0].index)
        try:
            l2=max(l[l<x[1]])
        except ValueError:
            l2=x[1]
        return x[0].loc[l2:,:]
    


def ifna(x):
    if isinstance(x,float): return np.nan
    else: return pd.DataFrame(x)
     

def aptocf(x):
    date=x['P'].apply(lambda x:[x[1]+pd.Timedelta(days=1)])
    x['DES_CASH_FLOW']=x['DES_CASH_FLOW'].apply(lambda x: [x])+date
    x['DES_CASH_FLOW']=x['DES_CASH_FLOW'].apply(lambda x:x[0].loc[x[1]:,:])
    x['FACTOR_SCHEDULE']=x['FACTOR_SCHEDULE'].apply(ifna)
    x['FACTOR_SCHEDULE']=x['FACTOR_SCHEDULE'].apply(lambda x: [x])+date
    x['FACTOR_SCHEDULE']=x['FACTOR_SCHEDULE'].apply(iffact)
    return x

def ifinv(x):
    if isinstance(x,float): return np.nan
    else: return x.to_dict()

def fNAN(x):
    return np.nan if x==0 else x


SerL2=SerL2.apply(aptocf)

# Обработка данных для запуска алгоритма бутстрэппинга

D={}
for i in range(len(SerL2)):
    for ind in SerL2[i].index:
        SerL2[i]['NEWCF']=0
        if isinstance(SerL2[i].loc[ind,'FACTOR_SCHEDULE'],float): D.update({(SerL2.index[i],ind):SerL2[i].loc[ind,'DES_CASH_FLOW']})
        else:
            
            fa=SerL2[i].loc[ind,'FACTOR_SCHEDULE']
            dcf=SerL2[i].loc[ind,'DES_CASH_FLOW']
            mat=pd.DataFrame(0,index=[SerL2[i].loc[ind,'MATURITY']],columns=['CPN','PAR','Factor'])
            dop1=pd.DataFrame(0,index=fa.index.difference(dcf.index),columns=dcf.columns)
            dop2=pd.DataFrame(0,index=dcf.index.difference(fa.index),columns=fa.columns)
            dcf=dcf.append(dop1)
            fa=fa.append(dop2)
            dcf=dcf.sort_index()
            fa=fa.sort_index()

            dcf['Factor']=(fa['Factor'].apply(fNAN)).fillna(method='ffill')
            
            k1=dcf['Factor'][:-1]
            
            k2=dcf['Factor'][1:]
            
            k1.index=k2.index
            
            pr=(k1-k2)*1000000
            dcf=dcf.loc[pr.index,:]
            
            pr2=pd.DataFrame(pr)
            pr2.columns=['PAR']
            dcf['PAR']=pr2['PAR']
            if SerL2[i].loc[ind,'MATURITY'] not in dcf.index:
                dcf=dcf.append(mat)
            dcf=dcf[['CPN','PAR']]
            D.update({(SerL2.index[i],ind):dcf})

def ismat(dat,x):
    if dat.loc[x,'MATURITY'] in list(dat.loc[x,'DES_CASH_FLOW'].index):
        return True
    else:
        return False


def to_df(x):
    f1=partial(ismat,x)
    x['TRUE_CF']=list(pd.Series(x.index).apply(f1))
    return x


totdf=pd.concat(SerL2.values)

tuples = list(zip(*[tuple(totdf.Base),tuple(totdf.index)]))
index = pd.MultiIndex.from_tuples(tuples, names=['Base', 'ISIN'])

totdf.index=index
# После обработки данных создаем новою переменную (D3) и заполняем информация по столбцам
D2=pd.Series(D)
D3=pd.DataFrame(D2)

D3.columns=['DES_CASH_FLOW']
D3.index.names=['Base', 'ISIN']
D3['MATURITY']=totdf['MATURITY']
D3['ISSUE_DT']=totdf['ISSUE_DT']
D3['P']=totdf['P']
D3['Freq']=totdf['Freq']
D3['Conv']=totdf['Conv']
D3['SIGMA']=totdf['SIGMA']
D3['ALPHA']=totdf['ALPHA']
D3['GAMMA']=totdf['GAMMA']
D3['PREM']=totdf['PREM']
D3['NFIXED']=totdf['NFIXED']
D3['FIXED']=totdf['FIXED']
D3['INTER']=totdf['INTER']
D3['INTS']=totdf['INTS']
D3['ISS']=totdf['ISS']
D3['TRUE_CF']=totdf['TRUE_CF']
D3['rfix']=0.0
D3['tod']=tod

# Дальнейшие действия носят очень локальный характер, связанный с преобразованием данных. Для понимания работы отдельных функций и участков кода, необходимо реализовать их и посмотреть, к чему это приведент. Дальнейшие комментарии даны после окончания этого блока.
inds=D3.index
D3.index=D3.index.get_level_values(1)
imp=D3
indx=pd.Series(imp.index)
indx.index=imp.index

def betwn(dat1,dat2,x):
    d1=dat1.loc[x,'DES_CASH_FLOW']
    d2=dat2[x]
    dif=d2.index.difference(d1.index)
    return d2.loc[dif,:].append(d1)

bet=partial(betwn,imp,FULLCF)
datj=indx.apply(bet)
j7=pd.Series(D3.index)
j7.index=D3.index

def toj7(DAT,dat,x):
    
    if x in dat.index:
        return dat[x]
    else: return DAT.loc[x,'DES_CASH_FLOW']
toj=partial(toj7,D3,datj)

insert=j7.apply(toj)
D3['DES_CASH_FLOW']=insert

D3['TRUE_CF']=list(D3.index)
D3['TRUE_CF']=D3['TRUE_CF'].apply(partial(ismat,D3))
D3.index=inds

ind1=pd.Series(D3.index.get_level_values(0)).apply(lambda x:[x])
ind1.index=D3.index
ind2=pd.Series(D3.index.get_level_values(1)).apply(lambda x:[x])
ind2.index=D3.index

D3['1st']=D3['TRUE_CF'].apply(lambda x: [x])+ind1+ind2+D3['ISSUE_DT'].apply(lambda x: [x])+D3['MATURITY'].apply(lambda x: [x])+D3['P'].apply(lambda x: [x])+D3['Freq'].apply(lambda x: [x])


todates2=partial(getdates,D3)       
D3['2st']=D3['DES_CASH_FLOW']


D3['Base']=D3['1st'].apply(lambda x: x[1])
def keyref(x):
    if x=='Ставка рефинансирования ЦБ РФ': x='Ключевая ставка ЦБ РФ'
    return x
D3['Base']=D3['Base'].apply(keyref)
D3['ISIN']=D3['1st'].apply(lambda x: x[2])

tuples = list(zip(*[tuple(D3['Base']),tuple(D3['ISIN'])]))
index = pd.MultiIndex.from_tuples(tuples, names=['Base', 'ISIN'])
D3.index=index

D3.loc['ROISfix 6M','rfix']= 8.46
D3.loc['Инфляция (Россия)','rfix']=3.3
D3.loc['Ключевая ставка ЦБ РФ','rfix']=9

def dropsim(p):
    p1=p[:-1]
    p2=p[1:]
    p1.index=p2.index
    bol=(p2!=p1)
    bol1=bol[bol==False].index
    return p[p.index.difference(bol1)].sort_values()
    
def recur(s,x):
    h=s[s==x].index
    pos=s.index.get_loc(h[0])
    if pos!=0: return [s[pos-1],x]
    else: return [tod,x]
    
def todate(dat,x):
    if dat.loc[x,'MATURITY'] in dat.loc[x,'DES_CASH_FLOW'].index:
        return list(dat.loc[x,'DES_CASH_FLOW'].index)[-2]
    else:
        return dat.loc[x,'MATURITY']-pd.Timedelta(days=365//dat.loc[x,'Freq'])

inss=D3.index

D3.index=D3.index.get_level_values(1)

FGg=D3.groupby('Base')

Betta={}

for gr in FGg.groups:
    
    dat=FGg.get_group(gr)
    dt=partial(todate,dat)
    dt2=pd.Series(dat.index).apply(dt)
    dt2
    dt2.index=dat.index
    dates=dt2[dt2>tod]
    dates=dropsim(dates)
    f1=partial(recur,dates)
    dates2=dates.apply(f1)
    dat2=dat.loc[dates2.index,:]
    dat2['INTS']=dates2
    
    Betta.update({gr:dat2})
   
D4=pd.concat(list(Betta.values()))
tuples = list(zip(*[tuple(D4['Base']),tuple(D4['ISIN'])]))
index = pd.MultiIndex.from_tuples(tuples, names=['Base', 'ISIN'])
D4.index=index

b0=Sheet1['b0'][-1]
b1=Sheet1['b1'][-1]
b2=Sheet1['b2'][-1]
tau=Sheet1['tau'][-1]

def r(x):
    """
    Функция рассчитывающая ставку при заданном времени в долях года по модели NS
    """
    return (b0+(b1+b2)*tau/x*(1-np.exp(-x/tau))-b2*np.exp(-x/tau))/10000


def splt(x):
    if x==x: return x.split(';')
    else: return x

# Объявление функций для реализации алгоритма бутстрэппинга

def P_F(p,x):
    """
    Основная функция для реализации бутсрэппинга. Возвращает массив функций для конечной оптимизации. Тип 1, для первой базовой группы.
    """
    smm=0
    for j in dft.index:
        if dft['CPN'][j]!=0:
            smm+=(dft['CPN'][j]+dft['PAR'][j])*np.exp(-(dft['R'][j]+iss)*dft['X'][j])
        else:
            smm+=((x+prem)*sum(dft['PAR'][j:])/100/dft['Freq'][j]*dft['GAMMA'][j]+dft['PAR'][j])*np.exp(-(dft['R'][j]+iss)*dft['X'][j])
    RES=smm-p
    return RES

def P_F2(p,k,x):
    """
    Основная функция для реализации бутсрэппинга. Возвращает массив функций для конечной оптимизации. Тип 1, для последующих базовых групп.
    """

    smm=0
    for j in dft.index:
        if dft['CPN'][j]!=0:
            smm+=(dft['CPN'][j]+dft['PAR'][j])*np.exp(-(dft['R'][j]+iss)*dft['X'][j])
        elif dft['CPN'][j]==0:
            iloc=dft.index.get_loc(j)-1
            j2=list(dft.index)[iloc]
            for i in range(len(k)):
                if j2<=k[i][2] and j2>k[i][1]:
                    smm+=((k[i][0]+prem)*sum(dft['PAR'][j:])/100/dft['Freq'][j]*dft['GAMMA'][j]+dft['PAR'][j])*np.exp(-(dft['R'][j]+iss)*dft['X'][j])
                    dft['CPN'][j]=(k[i][0]+prem)*sum(dft['PAR'][j:])/100
        else:
            smm+=((x+prem)*sum(dft['PAR'][j:])/100/dft['Freq'][j]*dft['GAMMA'][j]+dft['PAR'][j])*np.exp(-(dft['R'][j]+iss)*dft['X'][j])
    RES=smm-p
    return RES

DF=D4.groupby('Base')

k=[]
# Реализация алгоритма бутстрэппинга. В цикле будет прогоняться информация по каждой базовой группе и оцениваться параметры вменненой спотовой кривой.
for key in DF.groups:
    tr=True
    dat=DF.get_group(key)
    if tr:
        for i in range(len(dat.index)):
            int1=dat.iloc[i,:]['P'][1]
            b0=Sheet1.loc[int1,'b0']
            b1=Sheet1.loc[int1,'b1']
            b2=Sheet1.loc[int1,'b2']
            tau=Sheet1.loc[int1,'tau']
            int2=dat.iloc[i,:]['INTS'][1]
            intx=dat.iloc[i,:]['INTS'][0]
            mat=dat.iloc[i,:]['MATURITY']
            dft=dat.iloc[i,:]['DES_CASH_FLOW'].loc[int1+pd.Timedelta(days=1):,:]
            dft['Freq']=dat.iloc[i,:]['Freq']
            dft['GAMMA']=dat.iloc[i,:]['GAMMA']
            dft['SIGMA']=dat.iloc[i,:]['SIGMA']
            comp=pd.Series(dft.index)
            if sum(comp.apply(lambda x: x<tod))!=0:
                kp=comp.apply(lambda x: x<intx)
                kp.index=comp
                kp=kp[kp==True].index
                integ=dft.index.get_loc(kp)+1
                dft.iloc[integ,0]=0
            p=dat.iloc[i,:]['P'][0]*sum(dft.PAR)/100
            iss=dat.iloc[i,:]['ISS']
            indx=pd.Series(dft.index)
            indx.index=dft.index
            prem=dat.iloc[i,:]['PREM']
            dft['X']=indx.apply(lambda x: (x-int1).days/365)
            dft['R']=dft['X'].apply(lambda x: r(x))
            dft['CPN'][1]=0
            pk=partial(P_F,p)
            x=fsolve(pk, 5)
            k.append([float(x[0]),intx,int2,prem])
            tr=False
    else:
        for i in range(len(dat.index)):
            int1=dat.iloc[i,:]['P'][1]
            int2=dat.iloc[i,:]['INTS'][1]
            intx=dat.iloc[i,:]['INTS'][0]
            mat=dat.iloc[i,:]['MATURITY']
            dft=dat.iloc[i,:]['DES_CASH_FLOW'].loc[int1+pd.Timedelta(days=1):,:]
            dft['Freq']=dat.iloc[i,:]['Freq']
            p=dat.iloc[i,:]['P'][0]*sum(dft.PAR)/100
            iss=dat.iloc[i,:]['ISS']
            indx=pd.Series(dft.index)
            indx.index=dft.index
            prem=dat.iloc[i,:]['PREM']
            dft['X']=indx.apply(lambda x: (x-int1).days/365)
            dft['R']=dft['X'].apply(lambda x: r(x))
            pk=partial(P_F2,p,k)
            x=fsolve(pk, 5)
            k.append([float(x[0]),intx,int2,prem])

k2=pd.Series(k)
k2.index=D4.index
D4['IND_B']=k2

# Запись полученых в результате бутстрэппинга ставок и временных интервалов, на которых они действовали

dfrates=pd.DataFrame(k2.apply(lambda x: x[0]),columns=['Ставка, %'])
dfrates['Нижняя граница']=k2.apply(lambda x: x[1])
dfrates['Верхняя граница']=k2.apply(lambda x: x[2])

writer = pd.ExcelWriter('Ставки.xlsx')

dfrates.to_excel(writer,'Ставки')


writer.save()

D4.index=D4.index.get_level_values(1)
sk=[]

# Восстановления неизвестных денежных потоков по облигациям с плавающей ставкой согласно прогнозам, полученным в результате бутстрэппинга

DF=D4.groupby('Base')
for group in DF.groups:
    dat=DF.get_group(group)
    L=list(dat['IND_B'])

    for ind in dat.index:
        cf=dat.loc[ind,'DES_CASH_FLOW']
        
        freq=dat.loc[ind,'Freq']
        bol=cf.CPN.apply(lambda x: x==0)
        bol2=bol[bol==True].index
        
        for k in bol2:
            posn=cf.index.get_loc(k)
            ps=list(cf.index)[posn-1]
            for l in range(len(L)):
                if ps>L[l][1] and ps<=L[l][2]:
                    cf.loc[k,'CPN']=(L[l][0]+dat.loc[ind,'PREM'])/100/freq*sum(cf.loc[k:,'PAR'])
        sk.append(cf)

for dt in range(len(sk)):
    if sk[dt].iloc[-1,0]==0:
        sk[dt].iloc[-1,0]=sk[dt].iloc[-2,0]
        


sk=pd.Series(sk)
sk.index=D4.index
D4['DES_CASH_FLOW_B']=sk



# Подготовка и преобразование данных для проведения параметрического алгоритма


D4['DES_CASH_FLOW_P']=Fdat2['DES_CASH_FLOW'].loc[D4['DES_CASH_FLOW_B'].index]

tuples = list(zip(*[tuple(D4.Base),tuple(D4.index)]))
index = pd.MultiIndex.from_tuples(tuples, names=['Base', 'ISIN'])

D4.index=index

Gdat=D4['P'].apply(lambda x: x[1]).apply(lambda x: Sheet1.loc[x,:])

D4=pd.concat([D4,Gdat],axis=1)


def iterouter(dat,cf,cols):
    """
    Функция принципиального преобразования данных под роеализацию параметрического алгоритма
    """
    sp=dat.index.get_level_values(0).unique()
    L1={}
    for key in sp:
        if len(dat.loc[key,:])<4: pass
        else:
            tr=True
            for j in range(len(dat.loc[key,:])):
                if tr:
                    ind=dat[cf][key][j].index
                    Lk=[]
                    for nm in cols:
                        Lk.append(pd.DataFrame(dat[nm][key][j],index=ind,columns=[nm]))
                    datk=pd.concat(Lk,axis=1)
                    DAT=pd.concat([dat[cf][key][j],datk],axis=1)
                    tr=False
                    DAT
                else:
                    ind=dat[cf][key][j].index
                    Lk=[]
                    for nm in cols:
                        Lk.append(pd.DataFrame(dat[nm][key][j],index=ind,columns=[nm]))
                    datk=pd.concat(Lk,axis=1)
                    datk=pd.concat([dat[cf][key][j],datk],axis=1)
                    DAT=DAT.append(datk)
            L1.update({key:DAT})
    return L1



D4['P2']=D4['P'].apply(lambda x: str(x[0])+','+str(x[1]))

L=iterouter(D4,'DES_CASH_FLOW_P',['Freq','SIGMA','ALPHA', 'GAMMA', 'PREM', 'NFIXED', 'FIXED', 'INTER','ISS','P2','ISIN']+list(Sheet1.columns))


# Объявление функций для расчета форвардных ставок

def rf(x1,leng,b0,b1,b2,tau):
    """
    Функция, возвращающая форвардную ставку, при заданых параметрах кривой
    """
    res=0
    for i in range(leng):
        denom=(1+(b0+(b1+b2)*tau/(x1-i/365)*(1-np.exp(-(x1-i/365)/tau))-b2*np.exp(-(x1-i/365)/tau))/10000)**(x1-i/365)
        x2=(x1-i/365)+1
        nom=(1+(b0+(b1+b2)*tau/x2*(1-np.exp(-x2/tau))-b2*np.exp(-x2/tau))/10000)**(x2)
        res+=nom/denom-1
    return res/leng

def rf2(x1,leng):
    """
    Функция, возвращающая форвардную ставку, использую параметры кривой, записанные в среде 
    """
    res=0
    for i in range(leng):
        denom=(1+(b0+(b1+b2)*tau/(x1-i/365)*(1-np.exp(-(x1-i/365)/tau))-b2*np.exp(-(x1-i/365)/tau))/10000)**(x1-i/365)
        x2=(x1-i/365)+1
        nom=(1+(b0+(b1+b2)*tau/x2*(1-np.exp(-x2/tau))-b2*np.exp(-x2/tau))/10000)**(x2)
        res+=nom/denom-1
    return res/leng

# Ввод количества итераций и ограничений на параметры по модели Нельсона-Сигеля для проведения параметрического алгоритма

niter= int(gui.winstring(text="Введите количество итераций:", mes=""))

mes0 = gui.winstring(text="Введите ограничения на b0 (min,max):", mes="")
gs0 = [float(x) for x in (mes0.split(","))]
fb0=lambda x: gs0[0]+(gs0[1]-gs0[0])*x
mes1 = gui.winstring(text="Введите ограничения на b1 (min,max):", mes="")
gs1 = [float(x) for x in (mes1.split(","))]
fb1=lambda x: gs1[0]+(gs1[1]-gs1[0])*x

mes2 = gui.winstring(text="Введите ограничения на b2 (min,max):", mes="")
gs2 = [float(x) for x in (mes2.split(","))]
fb2=lambda x: gs2[0]+(gs2[1]-gs2[0])*x

mest = gui.winstring(text="Введите ограничения на tau (min,max):", mes="")
gst = [float(x) for x in (mest.split(","))]
ftau=lambda x: gst[0]+(gst[1]-gst[0])*x

vec=[fb0,fb1,fb2,ftau]

dat=sobol_seq.i4_sobol_generate(4, niter)


def outbounds(v):
    def bounds(x):
        return v(x)
    return bounds

dat=pd.DataFrame(dat)
for i in dat.columns:
    bb=outbounds(vec[i])
    dat[i]=dat[i].apply(bb)
dat.columns=['b0','b1','b2','tau']


# объявление вспомогательных функций
def rfdf(df):
    return (df['b0']+(df['b1']+df['b2'])*df['tau']/df['Time']*(1-np.exp(-df['Time']/df['tau']))-df['b2']*np.exp(-df['Time']/df['tau']))/10000
    
def iszero(x):
    if x==0: return x
    else: return x(dat['b0'],dat['b1'],dat['b2'],dat['tau'])

def topar(dat,x):
    return np.sum(dat.loc[x:,'PAR'])


def prefin(x):
    if x[1]==0: return x[0]
    else: return x[1]


def toDat(x):
    
    """
    Функция реализующая параметрический алгоритм. 
    Переменная - Дэйта фрэйм, содержащий информацию по облигациям, привязанным к одному индикатору.
    Возвращает кортеж с оценками параметров и спрогнозированными денежными потоками по облигациям.
    """
    
    nps=pd.DataFrame(list(x[x['CPN']!=0].index),index=x[x['CPN']!=0].index,columns=['D'])
    nps['Freq']=x[x['CPN']!=0]['Freq']
    vop=nps[nps['D'].apply(lambda x: (x-tod).days/365)>0]
    vop['D']=vop['D'].apply(lambda x: (x-tod).days/365)+1/vop.Freq
    iidn=list(vop[vop['D']==min(vop['D'])].index)[0]
    psd=nps[nps['D']==iidn]
    dft=psd['D']
    y=pd.Series(x[x['CPN']==0].index.unique())
    y.index=y
    y=y.sort_index()

    y=dft.append(y)
    y=y-x['ALPHA'][y.index].apply(lambda z: pd.Timedelta(days=z))
    y[1:]=y[:-1]
    y=y[1:]
    
    ser1=y.apply(lambda z2: (z2-tod).days/365)
    ser1=ser1.apply(lambda z:[z])+x.loc[ser1.index,'SIGMA'].apply(lambda z:[z])
    funct=ser1.apply(lambda y2: partial(rf,y2[0],y2[1]))
    emp=pd.DataFrame(0,index=x.index,columns=['Func'])
    emp.loc[y.index,'Func']=funct
    
    x['Func']=emp['Func']
    tuples = list(zip(*[tuple(x.P2),tuple(x.index)]))
    index = pd.MultiIndex.from_tuples(tuples, names=['P2', 'Date'])
    x.index=index
    sp2=x.index.get_level_values(0).unique()
    Lp=[]
    P=[]
    price=sp2[-1]
    x['Time']=0
    
    for price in sp2:
        p=float(price.split(',')[0])
        
        d=pd.Timestamp(price.split(',')[1])
        df=x.loc[price,:][tod+pd.Timedelta(days=1):]
        
        df['Time']=(pd.Series(df.index,index=df.index)-d).apply(lambda x: x.days/365)
        
        dfe=(p/100*sum(df['PAR'])-sum((df['CPN']+df['PAR'])*np.exp(-(rfdf(df)+df['ISS'])*df['Time'])))

        df['FORW']=df['Func'].apply(iszero)
        
        df['IND']=pd.Series(df.index,index=df.index)
        df['RES']=df['IND'].apply(partial(topar,df))
        df['Float']=(df['FORW']+df['PREM']/100)*df['RES']/df['Freq']
        Lp.append((dfe-sum(df['Float']*np.exp(-(rfdf(df)+df['ISS'])*df['Time'])))**2)
        P.append(df['RES'])
    fin=sum(Lp)
    params=dat.loc[fin.argmin(),:]
    tss=(fin[fin.argmin()]/len(sp2))**0.5
    params['MSE']=tss

    SSD=pd.concat(P)
    x.index=x.index.get_level_values(1)

    x['RES']=0
    x.loc[SSD.index,'RES']=SSD

    x['d2']=x['P2'].apply(lambda x: pd.Timestamp(x.split(',')[1]))
    
    x['Time']=(pd.Series(x.index,index=x.index)-x['d2'].apply(lambda z: pd.Timestamp(z))).apply(lambda z: z.days/365)

    b0=params['b0']
    b1=params['b1']
    b2=params['b2']
    tau=params['tau']
    
    x['Time2']=x['Time'].apply(lambda x: [x])+x['SIGMA'].apply(lambda x: [x])+[b0]+[b1]+[b2]+[tau]

    x['FORW']=x['Time2'].apply(lambda x: rf(x[0],x[1],x[2],x[3],x[4],x[5]))
    
    x['Float']=(x['FORW']+x['PREM']/100)*x['RES']/x['Freq']
    x['CPN2']=x['Float'].apply(lambda x: [x])+x['CPN'].apply(lambda x: [x])
    
    x['CPN2']=x['CPN2'].apply(prefin)
    x['CPN']=x['CPN2']

    tuples = list(zip(*[tuple(x.ISIN),tuple(x.index)]))
    index = pd.MultiIndex.from_tuples(tuples, names=['ISIN', 'Date'])

    x.index=index
    LF={}
    for ind in (x.index.get_level_values(0)).unique():
        LF.update({ind:x.loc[ind,['CPN','PAR']]})
    return params,LF

# Запись оценок параметров индикаторных кривых
for key in L.keys():
    L[key]=toDat(L[key])

L1={}
for j in L.keys():
    L1.update({j:L[j][0]})
L2={}
for j in L.keys():
    L2.update({j:L[j][1]})

DFP=pd.concat(list(L1.values()),axis=1)
DFP.columns=L1.keys()

writer = pd.ExcelWriter('Parametric.xlsx')
DFP.to_excel(writer,'Parametric')
writer.save()

L3={}
for j in L2.keys():
    L3.update(L2[j])
    

datP=pd.Series(list(L3.values()),index=list(L3.keys()))


iid=D4.index    
D4.index=D4.index.get_level_values(1)
D4.loc[datP.index,'DES_CASH_FLOW_P']=datP

diff=D4.index.difference(datP.index)

D4.loc[diff,'DES_CASH_FLOW_P']=D4.loc[diff,'DES_CASH_FLOW_B']

D4.index=iid

# Присовокупление вновь полученных данных по алгоритму бутстрэппинга к исходному массиву для перепроведения исходной процедуры оценки Z-спредов эмитентов. Алгоритм в точночти повторяется.
General2.index=General2.ISIN
General2.loc[D4['ISIN'],'Плавающая ставка']='Нет'

def todatestr(x):
    a=x[0:4]
    b=x[5:7]
    c=x[8:10]
    y='.'.join([c,b,a])
    return y
def invCF(x):
    """
    Обращение формата в строку для вновь полученных данных по денежным потокам
    """

    strind=pd.Series(x.index).apply(lambda x: str(x))
    strind=strind.apply(todatestr)
    x.index=strind
    h=str(x).strip()
    p=h.split('\n')

    for i in range(len(p)):
        p[i]=p[i].replace('  ',' ')
        p[i]=p[i].replace('  ',' ')
        p[i]=p[i].replace('  ',' ')
        p[i]=p[i].replace('  ',' ')
        p[i]=p[i].replace('  ',' ')
    p=' '.join(p)

    p=p.replace('  ',' ')
    p=p.replace('  ',' ')
    p=p.replace('  ',' ')
    p=p.replace('  ',' ')
    p=p[12:]
    return p

# Непосредственное добавление новых данных
D4['DES_CASH_FLOW_B2']=D4['DES_CASH_FLOW_B'].apply(invCF)
D4['DES_CASH_FLOW_P2']=D4['DES_CASH_FLOW_P'].apply(invCF)

# Сейчас необходимо переместится в раздел, который ранее был отмечен *. Последующие действия дублирую действия, заключенные между * и **, только для новых данных. В итоге получаются докалиброванные Z-спреды эмитентов.
D4.index=D4['ISIN']
General2.index=General2['ISIN']

General2['DES_CASH_FLOW_B']=General2['DES_CASH_FLOW']

General2['DES_CASH_FLOW_P']=General2['DES_CASH_FLOW']

General2.loc[D4['ISIN'],'DES_CASH_FLOW_B']=D4['DES_CASH_FLOW_B2']


S_G_F=General2[General2['Плавающая ставка']=='Нет'].dropna(axis=1,how='all')

S_G_F2=S_G_F.loc[S_G_F['Ставка купона'].apply(dropfx2),:]

S_G_F2=S_G_F2.append(General2.loc[D4['ISIN'],:])


S_G_F2['Newmat']=S_G_F2['DES_CASH_FLOW_B'].apply(lambda x: x.split())

S_G_F2['Newmat']=S_G_F2['Newmat'].apply(lambda x: str_to_ts(x[-3]))


S_G_F2['Newmat']=(S_G_F2['Newmat']-S_G_F2['MATURITY'])
S_G_F2['Newmat']=S_G_F2['Newmat'].apply(lambda x: x.days)
S_G_F2['Newmat']=S_G_F2['Newmat'].apply(lambda x: abs(x))

kp=S_G_F2['Newmat'].apply(lambda x : x<15)


S_G_F2=S_G_F2[kp]

S_G_F2['Dates']=S_G_F2['DES_CASH_FLOW_B']

def cout(y):
    x=y.split()
    k=len(x)//3
    sm=0
    for i in range(k-1):
        sm+=float(x[3*i+2])
    y=' '.join(x[:-1])
    y+=" "+str(1000000-sm)
    return y

def ssm(y):
    x=y.split()
    k=len(x)//3
    sm=0
    for i in range(k):
        sm+=float(x[3*i+2])
    return sm==1000000

S_G_F2['DES_CASH_FLOW_B']=S_G_F2['Dates'].apply(cout)

Emit_F=S_G_F2.groupby('Краткое название эмитента')
def notNan(x):
    return 0 if x!=x else x

nam_f=S_G_F2['FULL']

stnam_f=['Date']+list(nam_f)
PX_ASK_F=dd.compare(PX_ASK, stnam_f);PX_ASK2_F=PX_ASK_F[nam_f];PX_ASK2_F.index=PX_ASK_F['Date'].apply(dd.str_to_ts)
PX_VOLUME_F=dd.compare(PX_VOLUME, stnam_f);PX_VOLUME2_F=PX_VOLUME_F[nam_f];PX_VOLUME2_F.index=PX_VOLUME_F['Date'].apply(dd.str_to_ts)
AVG_PX_F=dd.compare(AVG_PX, stnam_f);AVG_PX2_F=AVG_PX_F[nam_f];AVG_PX2_F.index=AVG_PX_F['Date'].apply(dd.str_to_ts)
PX_BID_F=dd.compare(PX_BID, stnam_f);PX_BID2_F=PX_BID_F[nam_f];PX_BID2_F.index=PX_BID_F['Date'].apply(dd.str_to_ts)



pd.Series(AVG_PX2_F.index)[pd.Series(AVG_PX2_F.index).apply(dd.weeked)]


inddat=pd.Series(AVG_PX2_F.index)[pd.Series(AVG_PX2_F.index).apply(dd.weeked)]

PX_ASK2_F=PX_ASK2_F.ix[inddat,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[inddat,:]
AVG_PX2_F=AVG_PX2_F.ix[inddat,:]
PX_BID2_F=PX_BID2_F.ix[inddat,:]

indeq=pd.Index(sorted(set(Sheet1.index) & set(PX_ASK2_F.index)))

PX_ASK2_F=PX_ASK2_F.ix[indeq,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[indeq,:]
AVG_PX2_F=AVG_PX2_F.ix[indeq,:]
PX_BID2_F=PX_BID2_F.ix[indeq,:]
Sheet1=Sheet1.ix[indeq,:]


CPN=dd.create_CF(S_G_F2,cf='DES_CASH_FLOW_B',sec='FULL',dot='ISSUE_DT',mat='MATURITY')

gf=AVG_PX2_F.apply(dd.col).apply(dd.row, axis=1)
fin=dd.outer(CPN,cf='CF',sec='Security', dot='ISSUE_DT',mat='MATURITY',G=Sheet1)


Z_WA=gf.applymap(fin)


def less(x):
    if sum(x.apply(lambda y: y<=-0.02))>0 or sum(x.apply(lambda y: y<-0))>len(x)//2 or sum(x.apply(lambda y: y>0.1))>0: return True
    else: return False

k=Z_WA.apply(less,axis=0)
p=pd.Series(k[k==True].index)
p=p.apply(lambda x: x[:-5])
p=p.apply(lambda x: x+" Corp")
Z_WA=Z_WA.drop(p,axis=1)

Z_WA=Z_WA.dropna(how='all',axis=1)

Z_WA=Z_WA.fillna(method='ffill').fillna(method='bfill')
writer = pd.ExcelWriter('Z_WA2.xlsx')
Z_WA.to_excel(writer,'Z_WA2')
writer.save()
PX_ASK2_F=PX_ASK2_F[Z_WA.columns]
AVG_PX2_F=AVG_PX2_F[Z_WA.columns]
PX_BID2_F=PX_BID2_F[Z_WA.columns]
PX_VOLUME2_F=PX_VOLUME2_F[Z_WA.columns]
P_sttm1_F=PX_ASK2_F.applymap(lambda x: [x])+AVG_PX2_F.applymap(lambda x: [x])+PX_BID2_F.applymap(lambda x: [x])

def pst(x):
    if x[1]!=x[1]: return np.nan
    if x[0]==x[0] and x[2]==x[2]:
        return np.median(x)
    if x[0]==x[0]: return min(x[0],x[1])
    if x[2]==x[2]: return max(x[1],x[2])
    else: return x[1]


P_int=P_sttm1_F.applymap(pst)

P_sttm2_F=PX_ASK2_F.applymap(lambda x: [x])+P_int.applymap(lambda x: [x])+PX_BID2_F.applymap(lambda x: [x])

P_stm=P_sttm2_F.applymap(pst)

gf2=P_stm.apply(dd.col).apply(dd.row, axis=1)

Z_ST=gf2.applymap(fin)

Z_ST=Z_ST.fillna(method='ffill').fillna(method='bfill')

S_G_F2.index=S_G_F2['FULL']

S_G_F2=S_G_F2.loc[Z_ST.columns,:]

Emit_F=S_G_F2.groupby('Краткое название эмитента')


Z_WA=Z_WA.iloc[1:,:]
Z_ST=Z_ST.iloc[:-1,:]
Z_ST.index=Z_WA.index

l=PX_VOLUME2_F.iloc[1:,:]/np.exp(scale*abs(Z_WA-Z_ST))

def getdat(dat,x):
    nm=list(dat.index)
    if nm.index(x.name)>0: ind=nm[nm.index(x.name)-1]
    else: ind=nm[nm.index(x.name)] 
    return dat.loc[ind,:]

gd=partial(getdat,l)

def liq(x):
    if x[1]==x[1]:return alpha*x[0]+(1-alpha)*x[1]
    else: return x[0]

L=pd.DataFrame(0,index=l.index,columns=l.columns)

for index in L.index:
   dt=l.loc[index,:].apply(lambda x: [x])+gd(l.loc[index,:]).apply(lambda x: [x])
   L.loc[index,:]=dt.apply(liq)


Ser_F=[pd.Series(Emit_F.get_group(name)['FULL'],name=name) for name in Emit_F.groups]

L_iss=[pd.Series(L[ser].apply(np.mean,axis=1),name=ser.name) for ser in Ser_F]

L_ISS=pd.DataFrame({b.name:b for b in L_iss})

l_Z=[pd.Series((Z_WA[ser]*l[ser]).apply(np.sum,axis=1),name=ser.name) for ser in Ser_F]
l_ZISS=pd.DataFrame({b.name:b for b in l_Z})

l_l=[pd.Series(l[ser].apply(np.sum,axis=1),name=ser.name) for ser in Ser_F]
l_lISS=pd.DataFrame({b.name:b for b in l_l})

gdl=partial(getdat,L_ISS)
L_ISS2=L_ISS.apply(gdl,axis=1)
L_ISS2.index=L_ISS.index

ISS=l_ZISS.applymap(lambda x:[x])+L_ISS2.applymap(lambda x:[x])+l_lISS.applymap(lambda x:[x])

def liqs(x):
    return x[0]/x[2]

def liq2(x):
    if x[3]==x[3] and x[1]==x[1]:
        return (x[0]+x[3]*x[1])/(x[2]+x[1])
    else:
        return liqs(x)
    
tr=False
for i in range(len(ISS)):
    if not tr:
        ISS.iloc[i,:]=ISS.iloc[i,:].apply(liqs)
        tr=True
    else:
        dt=ISS.iloc[i,:]+ISS.iloc[i-1,:].apply(lambda x: [x])
        ISS.iloc[i,:]=dt.apply(liq2)

ISS=ISS.fillna(method='ffill').fillna(method='bfill')


ISS=ISS.dropna(axis=1)

# Запись докалиброванных оценок Z-спредов при использовании информации по бутстрэппингу

F2=ISS[General2.loc[D4.ISIN,'Краткое название эмитента']]
F2=ISS[F2.columns.unique()]
writer = pd.ExcelWriter('ISS_Floaters_Bootstrapping.xlsx')
F2.to_excel(writer,'ISS_Floaters_Bootstrapping')
writer.save()






# Присовокупление вновь полученных данных по параметрическому алгоритму к исходному массиву для перепроведения исходной процедуры оценки Z-спредов эмитентов. Алгоритм в точночти повторяется.



S_G_F2['Dates2']=S_G_F2['DES_CASH_FLOW_P']

def cout(y):
    x=y.split()
    k=len(x)//3
    sm=0
    for i in range(k-1):
        sm+=float(x[3*i+2])
    y=' '.join(x[:-1])
    y+=" "+str(1000000-sm)
    return y

def ssm(y):
    x=y.split()
    k=len(x)//3
    sm=0
    for i in range(k):
        sm+=float(x[3*i+2])
    return sm==1000000

S_G_F2['DES_CASH_FLOW_P']=S_G_F2['Dates2'].apply(cout)

Emit_F=S_G_F2.groupby('Краткое название эмитента')
def notNan(x):
    return 0 if x!=x else x

nam_f=S_G_F2['FULL']

stnam_f=['Date']+list(nam_f)
PX_ASK_F=dd.compare(PX_ASK, stnam_f);PX_ASK2_F=PX_ASK_F[nam_f];PX_ASK2_F.index=PX_ASK_F['Date'].apply(dd.str_to_ts)
PX_VOLUME_F=dd.compare(PX_VOLUME, stnam_f);PX_VOLUME2_F=PX_VOLUME_F[nam_f];PX_VOLUME2_F.index=PX_VOLUME_F['Date'].apply(dd.str_to_ts)
AVG_PX_F=dd.compare(AVG_PX, stnam_f);AVG_PX2_F=AVG_PX_F[nam_f];AVG_PX2_F.index=AVG_PX_F['Date'].apply(dd.str_to_ts)
PX_BID_F=dd.compare(PX_BID, stnam_f);PX_BID2_F=PX_BID_F[nam_f];PX_BID2_F.index=PX_BID_F['Date'].apply(dd.str_to_ts)



pd.Series(AVG_PX2_F.index)[pd.Series(AVG_PX2_F.index).apply(dd.weeked)]


inddat=pd.Series(AVG_PX2_F.index)[pd.Series(AVG_PX2_F.index).apply(dd.weeked)]

PX_ASK2_F=PX_ASK2_F.ix[inddat,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[inddat,:]
AVG_PX2_F=AVG_PX2_F.ix[inddat,:]
PX_BID2_F=PX_BID2_F.ix[inddat,:]

indeq=pd.Index(sorted(set(Sheet1.index) & set(PX_ASK2_F.index)))

PX_ASK2_F=PX_ASK2_F.ix[indeq,:]
PX_VOLUME2_F=PX_VOLUME2_F.ix[indeq,:]
AVG_PX2_F=AVG_PX2_F.ix[indeq,:]
PX_BID2_F=PX_BID2_F.ix[indeq,:]
Sheet1=Sheet1.ix[indeq,:]


CPN=dd.create_CF(S_G_F2,cf='DES_CASH_FLOW_P',sec='FULL',dot='ISSUE_DT',mat='MATURITY')

gf=AVG_PX2_F.apply(dd.col).apply(dd.row, axis=1)
fin=dd.outer(CPN,cf='CF',sec='Security', dot='ISSUE_DT',mat='MATURITY',G=Sheet1)


Z_WA=gf.applymap(fin)


def less(x):
    if sum(x.apply(lambda y: y<=-0.02))>0 or sum(x.apply(lambda y: y<-0))>len(x)//2 or sum(x.apply(lambda y: y>0.1))>0: return True
    else: return False

k=Z_WA.apply(less,axis=0)
p=pd.Series(k[k==True].index)
p=p.apply(lambda x: x[:-5])
p=p.apply(lambda x: x+" Corp")
Z_WA=Z_WA.drop(p,axis=1)

Z_WA=Z_WA.dropna(how='all',axis=1)

Z_WA=Z_WA.fillna(method='ffill').fillna(method='bfill')
writer = pd.ExcelWriter('Z_WA2.xlsx')
Z_WA.to_excel(writer,'Z_WA2')
writer.save()
PX_ASK2_F=PX_ASK2_F[Z_WA.columns]
AVG_PX2_F=AVG_PX2_F[Z_WA.columns]
PX_BID2_F=PX_BID2_F[Z_WA.columns]
PX_VOLUME2_F=PX_VOLUME2_F[Z_WA.columns]
P_sttm1_F=PX_ASK2_F.applymap(lambda x: [x])+AVG_PX2_F.applymap(lambda x: [x])+PX_BID2_F.applymap(lambda x: [x])

def pst(x):
    if x[1]!=x[1]: return np.nan
    if x[0]==x[0] and x[2]==x[2]:
        return np.median(x)
    if x[0]==x[0]: return min(x[0],x[1])
    if x[2]==x[2]: return max(x[1],x[2])
    else: return x[1]


P_int=P_sttm1_F.applymap(pst)

P_sttm2_F=PX_ASK2_F.applymap(lambda x: [x])+P_int.applymap(lambda x: [x])+PX_BID2_F.applymap(lambda x: [x])

P_stm=P_sttm2_F.applymap(pst)

gf2=P_stm.apply(dd.col).apply(dd.row, axis=1)

Z_ST=gf2.applymap(fin)

Z_ST=Z_ST.fillna(method='ffill').fillna(method='bfill')

S_G_F2.index=S_G_F2['FULL']

S_G_F2=S_G_F2.loc[Z_ST.columns,:]

Emit_F=S_G_F2.groupby('Краткое название эмитента')


Z_WA=Z_WA.iloc[1:,:]
Z_ST=Z_ST.iloc[:-1,:]
Z_ST.index=Z_WA.index

l=PX_VOLUME2_F.iloc[1:,:]/np.exp(scale*abs(Z_WA-Z_ST))

def getdat(dat,x):
    nm=list(dat.index)
    if nm.index(x.name)>0: ind=nm[nm.index(x.name)-1]
    else: ind=nm[nm.index(x.name)] 
    return dat.loc[ind,:]

gd=partial(getdat,l)

def liq(x):
    if x[1]==x[1]:return alpha*x[0]+(1-alpha)*x[1]
    else: return x[0]

L=pd.DataFrame(0,index=l.index,columns=l.columns)

for index in L.index:
   dt=l.loc[index,:].apply(lambda x: [x])+gd(l.loc[index,:]).apply(lambda x: [x])
   L.loc[index,:]=dt.apply(liq)


Ser_F=[pd.Series(Emit_F.get_group(name)['FULL'],name=name) for name in Emit_F.groups]

L_iss=[pd.Series(L[ser].apply(np.mean,axis=1),name=ser.name) for ser in Ser_F]

L_ISS=pd.DataFrame({b.name:b for b in L_iss})

l_Z=[pd.Series((Z_WA[ser]*l[ser]).apply(np.sum,axis=1),name=ser.name) for ser in Ser_F]
l_ZISS=pd.DataFrame({b.name:b for b in l_Z})

l_l=[pd.Series(l[ser].apply(np.sum,axis=1),name=ser.name) for ser in Ser_F]
l_lISS=pd.DataFrame({b.name:b for b in l_l})

gdl=partial(getdat,L_ISS)
L_ISS2=L_ISS.apply(gdl,axis=1)
L_ISS2.index=L_ISS.index

ISS=l_ZISS.applymap(lambda x:[x])+L_ISS2.applymap(lambda x:[x])+l_lISS.applymap(lambda x:[x])

def liqs(x):
    return x[0]/x[2]

def liq2(x):
    if x[3]==x[3] and x[1]==x[1]:
        return (x[0]+x[3]*x[1])/(x[2]+x[1])
    else:
        return liqs(x)
    
tr=False
for i in range(len(ISS)):
    if not tr:
        ISS.iloc[i,:]=ISS.iloc[i,:].apply(liqs)
        tr=True
    else:
        dt=ISS.iloc[i,:]+ISS.iloc[i-1,:].apply(lambda x: [x])
        ISS.iloc[i,:]=dt.apply(liq2)

ISS=ISS.fillna(method='ffill').fillna(method='bfill')


ISS=ISS.dropna(axis=1)
# Запись докалиброванных оценок Z-спредов при использовании информации по параметрическому алгоритму


F2=ISS[General2.loc[D4.ISIN,'Краткое название эмитента']]
F2=ISS[F2.columns.unique()]
writer = pd.ExcelWriter('ISS_Floaters_Parametric.xlsx')
F2.to_excel(writer,'ISS_Floaters_Parametric')
writer.save()






