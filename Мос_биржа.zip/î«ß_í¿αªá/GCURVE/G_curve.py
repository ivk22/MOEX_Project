﻿# -*- coding: utf-8 -*-
"""
Created on Fri Aug 25 16:28:31 2017

@author: KarpikovIV
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 20:35:58 2017

@author: I
"""
import multiprocessing as mm
import numpy as np
import pandas as pd
import time
from functools import partial
import scipy.optimize as so


# Объявление необходимых функций

def Pcalc(dat,DAT):
    """
    Основная расчетная функция. Рассчитывает взвешенный квадрат ошибки на всем множестве возможных значений параметров.
    """
    return DAT[1]*((sum([(DAT[0][0]["CPN"][x]+DAT[0][0]["PAR"][x])*np.exp(-(dat['b0']+(dat['b1']+dat['b2'])*dat['tau']/DAT[0][0]["DIF"][x]*(1-np.exp(-DAT[0][0]["DIF"][x]/dat['tau']))-dat['b2']*np.exp(-DAT[0][0]["DIF"][x]/dat['tau']))*DAT[0][0]["DIF"][x]/10000) for x in range(len(DAT[0][0]["DIF"]))]))/1000-DAT[0][1]/100*DAT[0][0]["PAR_RESID"]/1000)**2

def str_to_ts(x):
    if type(x)==str: 
        a=x[0:2]
        b=x[3:5]
        c=x[6:]
        y='.'.join([b,a,c])
        x=pd.Timestamp(y)
    return x

def create_info(Gen,CPN,y):
    """
    Функция принципиального преобразования данных под реализацию алгоритма оценки. Возвращает специальным образом организованные объект (кортеж длиной 2 из словаря и объекта с плавающей точкой).
    """

    if y[1]!=y[1]: return 0,0
    COP={"DIF":[], "CPN":[], "PAR": [], "PAR_RESID": np.nan,"НКД":np.nan}
    tod=y[2]
    ind=CPN['Security'].index(y[0])
    if y[2]>CPN['MATURITY'][ind] or y[2]<CPN['ISSUE_DT'][ind]: return 0,0
    n=CPN['LENGTH'][ind]
    k=int(n/3)
    for j in range(k):
        COP["DIF"].append((str_to_ts(CPN['CF'][ind][3*j])-tod).days/365)
        COP["CPN"].append(float(CPN['CF'][ind][1+3*j]))
        COP["PAR"].append(float(CPN['CF'][ind][2+3*j]))
    Tod_=[x for x in range(len(COP["DIF"])) if COP["DIF"][x]>0]
    if not Tod_: return 0,0
    try:
        dt=-max([COP["DIF"][x] for x in range(len(COP["DIF"])) if COP["DIF"][x]<=0 and COP["CPN"][x]!=0])
    except ValueError:
        dt=(tod-Gen.loc[y[0],'ISSUE_DT']).days/365
    
    COP["CPN"]=[COP["CPN"][x] for x in Tod_]
    COP["PAR"]=[COP["PAR"][x] for x in Tod_]
    COP["DIF"]=[COP["DIF"][x] for x in Tod_]
    COP["PAR_RESID"]=sum(COP["PAR"])
    try:
        k=min([x for x in range(len(COP["CPN"])) if COP["CPN"][x]!=0])
        d2=COP["DIF"][k]
        COP["НКД"]=COP["CPN"][k]*dt/(dt+d2)
    except ValueError:
        COP["НКД"]=0
    return COP,y[1]

# Тонкость, обусловленная распараллеливанием процессов.
if __name__=='__main__':
    import os
    directory=input('Введите путь к данному файлу: ')
    
    os.chdir(directory)
    
    import pandas as pd 
    from matplotlib import pyplot as plt
    import statsmodels.api as sm 
    import statsmodels.formula.api as smf
    import tkinter as tk
    from tkinter import *
    from tkinter import filedialog as fd
    from library import *
    from library import sobol_seq
    from library import data_download as dd
    import fractions as fr
    from fractions import Fraction as fr
    import datetime as dt
    import math as mt
    import time
    import xlsxwriter
    def ytm(p,D,y):
        """
        Функция, расчитывающая YTM
        """
        return (p*D['PAR_RESID']/100+D['НКД'])-sum([(D['CPN'][x]+D['PAR'][x])*np.exp(-D['DIF'][x]*y) for x in range(len(D['DIF']))])

    def durcalc(p,D,ytm):
        """
        Функция, расчитывающая модифицированную дюрацию
        """
        res=sum([(D['CPN'][x]+D['PAR'][x])*np.exp(-D['DIF'][x]*ytm)*D['DIF'][x] for x in range(len(D['CPN']))])/(p/100*D['PAR_RESID'])/(1+ytm)
        return res
    
    def apdur(x):
        """
        Функция, добавляющая модифицированную дюрацию для облигаций,
        у которых она не была расчитана на какую либо из дат
        """
        if x[0:2]==(0,0): return np.nan
        if x[1]==x[1] and x[2]!=x[2]:
            fi=partial(ytm,x[1],x[0])
            yld=so.fsolve(fi,0.085)
            return durcalc(x[1],x[0],float(yld[0]))
        else: return x[2]
    # Загрузка и обработка данных
    xls_file=dd.choose_excel()
    yd=365
    na_v=['#N/A Field Not Applicable', '#N/A N/A', '#N/A','NA','#NA','N/A', 'Na','na','#N/A Invalid Field', '#N/A Invalid Security', '#N/A Invalid Parameter']
    PX_LAST=xls_file.parse(sheetname='PX_LAST',na_values=na_v) # Массив данных с ценами
    General=xls_file.parse(sheetname='GENERAL',na_values=na_v) # Массив данных с общей информацией
    
    DUR=xls_file.parse(sheetname='DUR',na_values=na_v) # Массив данных с дюрациями
    
    # Удаляем пустые строки и столбцы из массивов данных
    var=['Security','CPN_TYP','DES_CASH_FLOW','callable','putable','MATURITY','des_notes','ISSUE_DT']
    General=dd.compare(General,var)
    nam=General['Security']
    stnam=['Date']+list(nam)
    PX_LAST=dd.compare(PX_LAST,stnam)
    # Преобразуем формат столбцов с датами
    PX_LAST['Date']=PX_LAST['Date'].apply(str_to_ts)
    
    PX_LAST2=PX_LAST[nam]
    
    PX_LAST2=PX_LAST2.set_index(PX_LAST['Date'])
    
    DUR=dd.compare(DUR,stnam)
    
    DUR['Date']=DUR['Date'].apply(str_to_ts)
    
    DUR2=DUR[nam]

    DUR2=DUR2.set_index(PX_LAST['Date'])
    
    # Выкидываем облигации, по которым нет ключевых данных
    func_expr=[('','!='),('','not in set(["FIXED", "ZERO COUPON", "STEP CPN"])'),('','!='),('','=="Y"'),('','=="Y"'),('type','==(float or int)'),('"LINKED" in str','.split()'),('','!=')]     
    kwa=dict(zip(var,func_expr))
    General2=General.drop(dd.drop_if(General=General, kwargs=kwa))
    nam=General2['Security']
    # Выкидываем выходные дни из массивов с ценами и дюрациями
    PX_LAST3=PX_LAST2[nam]

    DUR3=DUR2[nam]
    DUR3=DUR3.asfreq('B')
    PX_LAST3=PX_LAST3.asfreq('B')
    PX_LAST3=PX_LAST3.dropna(how='all',axis=1)
    DUR3=DUR3[PX_LAST3.columns]
    # Преобразуем формат столбцов с датами для массива с общей информацией
    General2['ISSUE_DT']=General2['ISSUE_DT'].apply(str_to_ts)
    General2['MATURITY']=General2['MATURITY'].apply(str_to_ts)
    General2.index=General2['Security']
    General2=General2.loc[PX_LAST3.columns,:]
    
    General=General2
    # Преобразуем данные общего характера при помощи функции create_info
    cf='DES_CASH_FLOW';sec='Security'; dot='ISSUE_DT';mat='MATURITY'
    
    niter= int(gui.winstring(text="Введите количество итераций:", mes=""))
    CPN=dd.create_CF(General2,cf='DES_CASH_FLOW',sec='Security', dot='ISSUE_DT',mat='MATURITY')
    PRICE=PX_LAST3.apply(dd.col).apply(dd.row,axis=1)+DUR3.applymap(lambda x: [x])
    t5=time.clock()
    
    KG2=PRICE.values.tolist()
    flat_list2=[]
    for sublist in KG2:
        for item in sublist:
            flat_list2.append(item)
    p=mm.Pool()
    f5=partial(create_info,General2,CPN)
    res5=p.map(f5,flat_list2)
    res52=[[res5[x] for x in range(y*len(PRICE.columns),y*len(PRICE.columns)+len(PRICE.columns))] for y in range(int(len(res5)/len(PRICE.columns)))]
    Pfunc = pd.DataFrame(res52, columns = PRICE.columns,index=PRICE.index)
    
    PRICE.applymap(f5)
    # Преобразование окончено
    print(time.clock()-t5)
    # Преобразуем данные для массивов с ценами и дюрациями
    Pfunc_=Pfunc+DUR3.applymap(lambda x: (x,))
    DUR3=Pfunc_.applymap(apdur)
    pp=Pfunc.applymap(lambda x: x[1])
    def nna(x):
        if sum(x!=0)<=10:return False
        else: return True
    
    pb=pp.apply(nna,axis=1)
    ind1=Pfunc.index
    ind2=Pfunc.loc[pb,:].index
    Pfunc=Pfunc.loc[ind2,:]
    DUR3=DUR3.loc[ind2,:]
    PX_LAST3=PX_LAST3.loc[ind2,:]
    # Преобразование окончено
    # Ввод ограничений на параметры G-кривой
    mes0 = gui.winstring(text="Введите ограничения на b0 (min,max):", mes="")
    gs0 = [float(x) for x in (mes0.split(","))]
    fb0=lambda x: gs0[0]+(gs0[1]-gs0[0])*x
    mes1 = gui.winstring(text="Введите ограничения на b1 (min,max):", mes="")
    gs1 = [float(x) for x in (mes1.split(","))]
    fb1=lambda x: gs1[0]+(gs1[1]-gs1[0])*x
    
    mes2 = gui.winstring(text="Введите ограничения на b2 (min,max):", mes="")
    gs2 = [float(x) for x in (mes2.split(","))]
    fb2=lambda x: gs2[0]+(gs2[1]-gs2[0])*x
    
    mest = gui.winstring(text="Введите ограничения на tau (min,max):", mes="")
    gst = [float(x) for x in (mest.split(","))]
    # Создаем функции для создания сетки, на которой мы будем обптимизировать параметры
    # Сетка, зависит от указанных диапазонов и рассчитывается при помощи последовательности ЧС
    ftau=lambda x: gst[0]+(gst[1]-gst[0])*x
    
    vec=[fb0,fb1,fb2,ftau]
    
    dat=sobol_seq.i4_sobol_generate(4, niter)
    
    
    def outbounds(v):
        def bounds(x):
            return v(x)
        return bounds
    
    dat=pd.DataFrame(dat)
    for i in dat.columns:
        bb=outbounds(vec[i])
        dat[i]=dat[i].apply(bb)
    # Создан массив dat - это и является сеткой
    # Преобразуем данные для расчета весов по дюрациям
    def invnan(x):
        if x!=x: return 0
        else: return x
    
    Pbool=Pfunc.applymap(lambda x: x!=(0,0))
    comb=(Pbool*DUR3).applymap(invnan)
    Dmin=comb.apply(lambda x: min(x[x!=0]),axis=1)
    Dmax=comb.apply(lambda x: max(x),axis=1)
    Dav=(Dmax+Dmin)/2
    
    def outdet(v):
        """
        Функция, рассчитывающая веса по дюрациям
        """
        def det(x):
            if x==0: return [np.nan,np.nan,np.nan]
            if x>v: w1=0
            else: w1=1-x/v
            if x<v: w2=0;w3=x/v
            else: w2=x/v-1;w3=2-x/v
            return [w1,w2,w3]
        return det
    # Применяем функцию outdet и агрегируем данные с весами
    tr=False
    for name in comb.index:
        fun=outdet(Dav[name])
        if not tr:
            comb2=pd.DataFrame(comb.ix[name,:].apply(fun).transpose(), columns=[name])
            tr=True
        else:
            comb2[name]=comb.ix[name,:].apply(fun).transpose()
    
    comb2=comb2.T
    
    TW1=comb2.applymap(lambda x: x[0]).apply(lambda x:x/sum(x[x==x]),axis=1)
    TW2=comb2.applymap(lambda x: x[1]).apply(lambda x:x/sum(x[x==x]),axis=1)
    TW3=comb2.applymap(lambda x: x[2]).apply(lambda x:x/sum(x[x==x]),axis=1)
    
    
    TWW=TW1+TW2+TW3
    TWW2=TWW.applymap(invnan)
    # Данные получены
    def invnanfunc(x):
        """
        Функция - заглушка для пропущенных данных
        """
        if x==(0,0): return {"CPN":[1],"PAR":[1],"DIF":[1],"PAR_RESID":1},0
        else: return x
    
    Pfunc2=Pfunc.applymap(invnanfunc)
    TWW2=TWW2/3
    dat=dat.applymap(lambda x: round(x,3))
    dat.columns=['b0','b1','b2','tau']
    TOT=Pfunc2.applymap(lambda x: [x])+TWW2.applymap(lambda x: [x])
    
    t1=time.clock()
    
    # Финальный расчет взвешенной суммы квадратов ошибок и выбор оптимальных параметров модели
    
    KG=TOT.values.tolist()
    # Применяем финальную функцию и получаем результаты расчетов
    flat_list=[]
    for sublist in KG:
        for item in sublist:
            flat_list.append(item)
    fs1=partial(Pcalc,dat)
    result=p.map(fs1,flat_list)
    result2=[[result[x] for x in range(y*len(TOT.columns),y*len(TOT.columns)+len(TOT.columns))] for y in range(int(len(result)/len(TOT.columns)))]
    df = pd.DataFrame(result2, columns = TOT.columns,index=TOT.index)
    # df - результат работы программы, однако необходимо преобразовать эти данные для вывода
    def TS(x):
        """
        Функция для вывода конечных результатов
        """
        sm=sum(x)
        ind=sm.argmin()
        return dat.iloc[ind,:].append(pd.Series(data=sm[ind]**0.5,index=['tss']))       
    df2=df.apply(TS,axis=1)
    df3=pd.DataFrame(np.nan,index=ind1.difference(ind2),columns=df2.columns)
    df2=df2.append(df3)
    df2=df2.loc[sorted(df2.index),:]
    df2=df2.fillna(method='ffill')
    # Данные преобразованы и готовы для вывода
    print(df2)
    print(time.clock()-t1)
    # Запись файла с результатами
    writer = pd.ExcelWriter('G.xlsx')
    df2.to_excel(writer,'Sheet1')
    writer.save()
    
    
    