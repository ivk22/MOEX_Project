# ! /usr/bin/env python
# ! _*_ coding: utf-8 _*_

"""
\n LIBRARY
=====

Library of support functions
"""
__version__ = 1.0
__all__ = ["rw", "gui"]