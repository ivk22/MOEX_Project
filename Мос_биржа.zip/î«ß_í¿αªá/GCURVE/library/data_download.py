# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 15:23:20 2017

@author: I
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 14:52:08 2017

@author: I
"""
import numpy as np
import pandas as pd 
import tkinter as tk
from tkinter import filedialog as fd
import datetime as dt
import time
import os
import itertools as it
import scipy.optimize as so
import sys


def str_to_ts(x):
    if type(x)==str: 
        a=x[0:2]
        b=x[3:5]
        c=x[6:]
        y='.'.join([b,a,c])
        x=pd.Timestamp(y)
    return x


def winstring(text="Введите текст:", mes="Поле для ввода"):
    """ Редактор одной строки """
    root = tk.Tk()
    v = tk.StringVar()
    w = tk.Label(root, text=text)
    w.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    w.pack(side=tk.LEFT)
    v.set(mes)
    ent = tk.Entry(root, textvariable=v, bg="blue", fg="white")
    ent.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    ent.pack(side=tk.LEFT)
    but = tk.Button(root, text="OK", fg="green", command=root.destroy)
    but.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    but.pack(side=tk.BOTTOM)
    root.mainloop()
    txt = v.get()
    return txt

def givenm(excelnm,NAs):
    for name in excelnm.sheet_names:
        sys.modules['__main__'].__setattr__(name, excelnm.parse(sheetname=name,na_values=NAs))


def choose_excel_G():
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title="Выберите файл с параметрами G-кривой", defaultextension=".xlsx", 
                            filetypes=[("Таблицы Excel", ".xlsx")], initialdir=os.getcwd()) 
    root.destroy()
    xls_file = pd.ExcelFile(fph)
    return xls_file

def choose_excel_Z():
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title="Выберите файл с данными по корпоративным облигациям", defaultextension=".xlsx", 
                            filetypes=[("Таблицы Excel", ".xlsx")], initialdir=os.getcwd()) 
    root.destroy()
    xls_file = pd.ExcelFile(fph)
    return xls_file


def choose_excel():
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title="Выберите файл с данными", defaultextension=".xlsx", 
                            filetypes=[("Таблицы Excel", ".xlsx")], initialdir=os.getcwd()) 
    root.destroy()
    xls_file = pd.ExcelFile(fph)
    return xls_file


def choose_date():
    mesdat = winstring(text="Введите дату отсчета (дд.мм.гг):", mes="")
    tod=dt.datetime.strptime(mesdat,'%d.%m.%y')
    return tod, mesdat

def compare(DF, names):
    res=DF
    if set(names) & set(DF.columns)!=set(names):
        comp=DF.apply(lambda x: set(names) & set(x)==set(names),axis=1)
        res=DF.ix[comp[comp].index[0]+1:,:]
        res.columns=DF.ix[comp[comp].index[0],:]
        res=res[names]
    return res

def drop_if(General, kwargs):
    ind=set()
    for j in kwargs.keys():
        for i in General.index:
            st=kwargs[j][0]+'(General[j][i])'
            if len(kwargs[j][1])==2:
                if eval(st+kwargs[j][1]+st):
                    ind.add(i)
            else:
                if eval(st+kwargs[j][1]):
                    ind.add(i)
    ind=list(ind)
    ind.sort()
    return ind

def create_CF(General,*,cf,sec,dot,mat):
    CPN={'CF':[], 'Security': [], 'ISSUE_DT':[], 'MATURITY':[],'LENGTH':[]}
    for i in General.index:
        CPN['CF'].append(General[cf][i].split(' '))
        CPN['LENGTH'].append(len(General[cf][i].split(' ')))
        CPN['Security'].append(General[sec][i])
        CPN['ISSUE_DT'].append(General[dot][i])
        CPN['MATURITY'].append(General[mat][i])

    ind=[x for x in range(len(CPN['CF'])) if str_to_ts(CPN['CF'][x][CPN['LENGTH'][x]-3])==str_to_ts(CPN['MATURITY'][x])]

    for name in CPN.keys():
        CPN[name]=[CPN[name][x] for x in ind]
    return CPN

def col(x):
    y=x.name
    res=[[y] +[k] for k in x]
    return res

def row(x):
    y=x.name
    res=[k+[y] for k in x]
    return res


def DepI(dic,*,cpn='CPN',par='PAR',rate='R',tim='TIME_ACC',lhs='LHS',sec='Security',pwa='P_wa'):
    def F(x):
        smm=0
        for j in range(len(dic[tim])):
            smm=smm+(dic[cpn][j]+dic[par][j])*np.exp(-(dic[rate][j]+x)*dic[tim][j])
        RES=smm-dic[lhs]
        return RES
    CALC=so.broyden1(F,0.02, f_tol=1)
    return CALC

def outer(CPN,cf,leng,sec,dot,mat):
    def create_info(y):
        if y[1]!=y[1] or y[3]!=y[3]: return np.nan
        COP={"DIF":[], "CPN":[], "PAR": [], "PAR_RESID": np.nan,} 
        tod=y[2]
        ind=CPN[sec].index(y[0])
        if y[2]>CPN[mat][ind] or y[2]<CPN[dot][ind]: return np.nan
        n=CPN[leng][ind]
        k=int(n/3)
        for j in range(k):
            COP["DIF"].append((str_to_ts(CPN[cf][ind][3*j])-tod).days/365)
            COP["CPN"].append(float(CPN[cf][ind][1+3*j]))
            COP["PAR"].append(float(CPN[cf][ind][2+3*j]))
        Tod_=[x for x in range(len(COP["DIF"])) if COP["DIF"][x]>0]
        if not Tod_: return np.nan
        COP["CPN"]=[COP["CPN"][x] for x in Tod_]
        COP["PAR"]=[COP["PAR"][x] for x in Tod_]
        COP["DIF"]=[COP["DIF"][x] for x in Tod_]
        COP["PAR_RESID"]=sum(COP["PAR"])
        frm=lambda b0,b1,b2,tau: ((sum([(COP["CPN"][x]+COP["PAR"][x])*np.exp(-(b0+(b1+b2)*tau/COP["DIF"][x]*(1-np.exp(-COP["DIF"][x]/tau))-b2*np.exp(-COP["DIF"][x]/tau))*COP["DIF"][x]/10000) for x in range(len(COP["DIF"]))]))/1000-y[1]/100*COP["PAR_RESID"]/1000)**2
        return frm
    return create_info


def weeked(x):
    Y=str(x)[0:4]
    M=str(x)[5:7]
    D=str(x)[8:10]
    res=dt.date(int(Y),int(M),int(D)).weekday()
    return True if res<5 else False

def outr(a):
    def recur(x):
        L=[]
        ind=np.nan
        for i in range(len(x)): 
            if x[i]==x[i]: 
                ind=i
                break
            else: L.append(0)
        if ind!=ind: pass
        else:
            tr=True
            for i in range(ind,len(x)):
                if tr:
                     L.append(x[i])
                     tr=False
                else:
                    if x[i]==x[i]:
                        if L[i-1]!=0:
                            L.append((1-a)*L[i-1]+a*x[i])
                        else: L.append(x[i])
                    else: L.append(0)
        return L
    return recur

def ziss(x):
    L=[]
    tr=True
    for i in range(len(x)):
        if tr:
            L.append((x[i][0]+x[i][2]*x[i][3])/(x[i][1]+x[i][3]))
            tr=False
        else:
            L.append((x[i][0]+L[i-1]*x[i][3])/(x[i][1]+x[i][3]))
    return L


def Settle(x):
    P_theor=[]
    P_sttlmnt=[]
    if x[0][1]==x[0][1]:
        for i in range(len(x)):
            if x[i][1]==x[i][1]: P_theor.append(x[i][1])
            else: P_theor.append(P_sttlmnt[i-1])
            if x[i][0]==x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(np.median([x[i][0],P_theor[i],x[i][2]]))
            if x[i][0]!=x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(min([P_theor[i],x[i][2]]))
            if x[i][0]==x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(max([P_theor[i],x[i][0]]))
            if x[i][0]!=x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(P_theor[i])
    
    else:
        for i in range(len(x)):
            P_theor.append(np.nan);P_sttlmnt.append(np.nan)
            if x[i][1]: 
                indstart=i
                break
        for i in range(indstart,len(x)):
            if x[i][1]==x[i][1]: P_theor.append(x[i][1])
            else: P_theor.append(P_sttlmnt[i-1])
            if x[i][0]==x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(np.median([x[i][0],P_theor[i],x[i][2]]))
            if x[i][0]!=x[i][0] and x[i][2]==x[i][2]: P_sttlmnt.append(min([P_theor[i],x[i][2]]))
            if x[i][0]==x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(max([P_theor[i],x[i][0]]))
            if x[i][0]!=x[i][0] and x[i][2]!=x[i][2]: P_sttlmnt.append(P_theor[i])
    return P_sttlmnt

