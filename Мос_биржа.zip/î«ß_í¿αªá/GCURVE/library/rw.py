# -*- coding: utf-8 -*-
"""
Чтение и запись в файл

"""
# Параметры и функции

import tkinter as tk

import tkinter.filedialog as fd

PTH = "d:/work.p/data/"

def read_txtfile(p, nm=""):
    """ Чтение строк из текстового файла """
    while(True):
        if nm != "":
            nm = input("Введите имя файла для чтения: ")
        fnm = p + nm
        try:
            fl = open(fnm, 'r')
            s = fl.readlines()
            fl.close()
            break
        except IOError:
            print("Файла с именем \"" + fnm + "\" нет")
    return s

def read_txtfile_g(tit="Открытие файла", defext=".txt",
                   ft=[("Текстовые файлы", ".txt")], ind="d:\\work.p"):
    """ Чтение строк из текстового файла """
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title=tit, defaultextension=defext, 
                        filetypes=ft, initialdir=ind) 
    root.destroy()
    if fph != "":
        fl = open(fph, 'r')
        s = fl.readlines()
        fl.close()
        return s
    else:
        return -1

def write_txtfile(s, p="d:\\work\\data", nm=""):
    """ Запись строк в файл """
    if nm != "":
        nm = input("Введите имя файла для записи: ")
    fnm = p + nm
    fl = open(fnm, 'w')
    fl.writelines(s)
    fl.close()
    return 0

def write_txtfile_g(s, tit="Открытие файла", defext=".txt",
                   ft=[("Текстовые файлы", ".txt")], ind="d:\\work.p"):
        if fph != "":
            fl = open(fnm, 'w')
            fl.writelines(s)
            fl.close()
            return 0
        else:
            return -1

def read_xlsx_g(tit="Открытие файла", defext=".xlsx",
                   ft=[("Таблицы Excel", ".xlsx")],
                   ind="d:\\work.p", sht="Sheet1"):
    """ Чтение файла xlsx во фрейм"""
    import pandas as pd
    root=tk.Tk()
    fph = fd.askopenfilename(parent=root, title=tit, defaultextension=defext, 
                        filetypes=ft, initialdir=ind) 
    root.destroy()
    if fph != "":
        xls_file = pd.ExcelFile(fph)
        s = xls_file.parse(sht)
        return s
    else:
        return -1
    

def write_xlsx(s, p="d:\\work\\data", nm="", sht="Sheet1"):
    """ Запись фрейма в файл xlsx"""
    import pandas as pd
    import xlsxwriter
    if nm != "":
        nm = input("Введите имя файла xlsx для записи: ")
    if sht != "":
        sht = input("Введите имя листа файла xlsx для записи (Sheet1, Лист1): ")
    fnm = p + nm
    writer = pd.ExcelWriter(fnm, engine='xlsxwriter')
    s.to_excel(writer, sheet_name=sht, encoding='utf-8')
    writer.save()
    return 0

def write_xlsx_g(s, tit="Открытие файла", defext=".xlsx",
                   ft=[("Таблицы Excel", ".xlsx")],
                   ind="d:\\work.p", sht="Sheet1"):
    """ Запись фрейма в файл xlsx"""
    import pandas as pd
    import xlsxwriter
    root=tk.Tk()
    fph = fd.asksaveasfilename(parent=root, title=tit, defaultextension=defext, 
                        filetypes=ft, initialdir=ind) 
    root=destroy()
    if fph != "":
        writer = pd.ExcelWriter(fph, engine='xlsxwriter')
        s.to_excel(writer, sheet_name=sht, encoding='utf-8')
        writer.save()
        return 0
    else:
        return -1