# -*- coding: utf-8 -*-
"""
Функции для создания графического интерфейса
"""

import tkinter as tk

def mnus(text="Выбор элементов", items=["первый", "второй", "третий"]):
    """ Создание меню для выбора нескольких элементов"""
    def CurSelectS(event):
        """ Фиксация выбора"""
        value = [lb.get(idx) for idx in lb.curselection()]
        chs.set(value)

    root = tk.Tk()
    w = tk.Label(root, text=text)
    w.config(bg="white", fg="black", cursor="hand2", font="Times 14 bold")
    w.pack(side=tk.TOP)
    # BooleanVar, StringVar, FloatVar, IntegerVar
    chs = tk.StringVar(master=root)
    lb = tk.Listbox(root, height=len(items), selectmode=tk.EXTENDED)    
    lb.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    for x in items:
        lb.insert(tk.END, x)
    lb.bind('<<ListboxSelect>>', CurSelectS)
    lb.pack(side=tk.TOP)
    finbut = tk.Button(root, text="OK", fg="green",
                         command=root.destroy)    
    finbut.config(bg="white", fg="black", cursor="hand2", font="Arial 14")    
    finbut.pack(side=tk.BOTTOM)
    tk.mainloop()
    cs = chs.get()
    choice = [x[1:-2] for x in cs[1:].split()]
    if len(choice) == 1:
        choice[0] = choice[0][:-1]
    return choice

def winstring(text="Введите текст:", mes="Поле для ввода"):
    """ Редактор одной строки """
    root = tk.Tk()
    v = tk.StringVar()
    w = tk.Label(root, text=text)
    w.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    w.pack(side=tk.LEFT)
    v.set(mes)
    ent = tk.Entry(root, textvariable=v, bg="blue", fg="white")
    ent.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    ent.pack(side=tk.LEFT)
    but = tk.Button(root, text="OK", fg="green", command=root.destroy)
    but.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    but.pack(side=tk.BOTTOM)
    root.mainloop()
    txt = v.get()
    return txt


def winfor(text="Вставляете значение для:", mes="Поле для ввода"):
    """ Редактор одной строки """
    root = tk.Tk()
    v = tk.StringVar()
    w = tk.Label(root, text=text)
    w.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    w.pack(side=tk.LEFT)
    v.set(mes)
    ent = tk.Entry(root, textvariable=v, bg="blue", fg="white")
    ent.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    ent.pack(side=tk.LEFT)
    but = tk.Button(root, text="OK", fg="green", command=root.destroy)
    but.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    but.pack(side=tk.BOTTOM)
    root.mainloop()
    txt = v.get()
    return txt


def windialog(text="Привет"):
    """ Создание сообщения с кнопками """
    def yes():
        """ Фиксация выбора"""
        chs.set("yes")
        root.destroy()

    def no():
        """ Фиксация выбора"""
        chs.set("no")
        root.destroy()

    def stop():
        """ Фиксация выбора"""
        chs.set("stop")
        root.destroy()

    root = tk.Tk()
    chs = tk.StringVar(master=root)

    # Текст сообщения
    w = tk.Label(root, text=text)
    w.config(bg="white", fg="black", cursor="hand2", font="Arial 14")
    w.grid(row=0, column=0, columnspan=3)

    # Кнопка "yes"
    butyes = tk.Button(root, text="Yes", fg="green", command=yes)
    butyes.config(bg="white", fg="black", cursor="hand2", font="Arial 10")
    butyes.grid(row=1, column=0)

    # Кнопка "no"
    butno = tk.Button(root, text="No", fg="green", command=no)
    butno.config(bg="white", fg="black", cursor="hand2", font="Arial 10")
    butno.grid(row=1, column=1)

    # Кнопка "Exit"
    butex = tk.Button(root, text="Exit", fg="green", command=stop)
    butex.config(bg="white", fg="black", cursor="hand2", font="Arial 10")
    butex.grid(row=1, column=2)

    tk.mainloop()
    choice = chs.get()
    return choice
